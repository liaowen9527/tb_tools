import os
import datetime

class FileInfo:
    def __init__(self):
        self.rootDir = ""
        self.fullname = ""
        self.filename = ""
        self.ext = ""

    def getFullPath(self):
        return r"%s\%s"%(self.rootDir, self.fullname)

    def rename(self, fullname):
        splitTemp = os.path.splitext(fullname)

        self.fullname = fullname
        self.filename = splitTemp[0]
        self.ext = splitTemp[1]

def get_files(dir_folder, extList):
    filename_list = []
    for root, subdir, files in os.walk(dir_folder):
        #print(root)  # 当前目录路径
        #print(subdir)  # 当前路径下所有子目录
        #print(files)  # 当前路径下所有非目录子文件
        for file in files:
            #".jpg"
            splitTemp = os.path.splitext(file)
            extTemp = splitTemp[1].lower()
            if extTemp in extList:
                file_info = FileInfo()
                file_info.rootDir = root
                file_info.fullname = file
                file_info.filename = splitTemp[0]
                file_info.ext = extTemp
                filename_list.append(file_info)
        
    return filename_list

def get_all_files(dir_folder):
    filename_list = []
    for root, subdir, files in os.walk(dir_folder):
        #print(root)  # 当前目录路径
        #print(subdir)  # 当前路径下所有子目录
        #print(files)  # 当前路径下所有非目录子文件
        for file in files:
            #".jpg"
            splitTemp = os.path.splitext(file)
            extTemp = splitTemp[1].lower()
            
            file_info = FileInfo()
            file_info.rootDir = root
            file_info.fullname = file
            file_info.filename = splitTemp[0]
            file_info.ext = extTemp
            filename_list.append(file_info)
                
        
    return filename_list

def find_file(dir_folder, extList, filename):
    filename_list = []
    for root, subdir, files in os.walk(dir_folder):
        #print(root)  # 当前目录路径
        #print(subdir)  # 当前路径下所有子目录
        #print(files)  # 当前路径下所有非目录子文件
        for file in files:
            #".jpg"
            splitTemp = os.path.splitext(file)
            extTemp = splitTemp[1].lower()
            if filename.lower() != splitTemp[0].lower():
                continue

            if extTemp in extList:
                file_info = FileInfo()
                file_info.rootDir = root
                file_info.fullname = file
                file_info.filename = splitTemp[0]
                file_info.ext = extTemp
                return file_info
        
    return {}

def get_ext(filename):
    return os.path.splitext(filename)[1]

# 字节bytes转化kb\m\g
def format_size(bytes):
    size = format_size_2(bytes)
    return "%s%s" % (size[0], size[1])

# 字节bytes转化kb\m\g
def format_size_2(bytes):
    try:
        bytes = float(bytes)
        kb = bytes / 1024
    except:
        print("传入的字节格式不对")
        return "Error"

    if kb >= 1024:
        M = kb / 1024
        if M >= 1024:
            G = M / 1024
            return ["%.2f" % (G), "GB"]
        else:
            return ["%.2f" % (M), "MB"]
    else:
        return ["%.2f" % (kb), "kb"]