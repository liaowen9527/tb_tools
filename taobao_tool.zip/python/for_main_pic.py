import os
import shutil
import json
import material_dao
import js_generator
import filesystem_helper

def copy_pic_to_dir(srcDir, destDir):
    if os.path.exists(destDir):
        #os.removedirs(analysis_folder) #删除空文件夹
        shutil.rmtree(destDir)
        os.mkdir(destDir)
    else:
        os.mkdir(destDir)

    picList = filesystem_helper.get_files(srcDir, [".jpg", ".png", ".bmp"])
    picList.sort()

    index = 0
    for picFile in picList:
        srcFile = r"%s/%s"%(srcDir, picFile)
        dstfile = r"%s/pic_%d%s"%(destDir, index, filesystem_helper.get_ext(picFile))
        
        shutil.copyfile(srcFile, dstfile)

        index = index + 1

copy_pic_to_dir(r"E:\code\main_pic_src", r"E:\code\aaa_copy")