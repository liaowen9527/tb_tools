import os
import sqlite3
import random
import json

class MaterialRecord:
    def __init__(self):
        self.number = 0
        self.srcNumber = ""
        self.type_str = ""
        self.desc1 = ""
        self.desc2 = ""
        self.baidu_shared = ""
        self.srcFolder = ""
        self.srcExtType = ""
        self.htmlPath = ""
        self.summaryStyle = ""

    def load_from_txt(self, filepath):
        f = open(filepath, 'r')
        self.srcFolder = f.readline().strip('\n')
        self.srcExtType = f.readline().strip('\n')
        self.type_str = f.readline().strip('\n')
        self.desc1 = f.readline().strip('\n')
        self.desc2 = f.readline().strip('\n')
        self.baidu_shared = f.readline().strip('\n')
        self.htmlPath = f.readline().strip('\n')
        self.summaryStyle = f.readline().strip('\n')

    def get_json_str(self):
        return {
            "number": self.number,
            "srcNumber": self.srcNumber,
            "srcFolder": self.srcFolder,
            "srcExtType": self.srcExtType,
            "srcDesc1": self.desc1,
            "srcDesc2": self.desc2,
            "baidu_shared": self.baidu_shared,
            "htmlPath": self.htmlPath,
            "summaryStyle": self.summaryStyle
        }

    def save_to_json(self, filepath):
        dict_data = self.get_json_str()

        f = open(filepath, 'w', encoding='utf-8')
        jsonStr = json.dumps(dict_data, ensure_ascii = False)
        f.write(jsonStr)
        f.close()

    def load_from_json(self, filepath):
        f = open(filepath, 'r', encoding='utf-8')
        setting = json.load(f)

        self.number = setting["number"]
        self.srcNumber = setting["srcNumber"]
        self.srcFolder = setting["srcFolder"]
        self.srcExtType = setting["srcExtType"]
        self.srcDesc1 = setting["srcDesc1"]
        self.srcDesc2 = setting["srcDesc2"]
        self.baidu_shared = setting["baidu_shared"]
        self.htmlPath = setting["htmlPath"]
        self.summaryStyle = setting["summaryStyle"]
        

class MaterialDao:
    def __init__(self, db_filepath):
        self.db_filepath = db_filepath
        self.create_if_not_exist()
        return 

    def create_if_not_exist(self):
        conn = sqlite3.connect(self.db_filepath)
        c = conn.cursor()

        c.execute('''CREATE TABLE IF NOT EXISTS material
                (id                     INT    NOT NULL,
                search_num              CHAR(50)    NOT NULL,
                type                    CHAR(50),
                desc1                   CHAR(50),
                desc2                   CHAR(50),
                baidu_shared            CHAR(250));''')

        conn.commit()
        conn.close()
        return

    def insert(self, record):
        conn = sqlite3.connect(self.db_filepath)
        c = conn.cursor()

        record.number = self.generate_id()
        record.srcNumber = self.generate_search_number(record.number, record.type_str)

        sql_string = "insert into material values(%d, \"%s\", \"%s\", \"%s\", \"%s\", \"%s\");"%(
            record.number, record.srcNumber, record.type_str, record.desc1, record.desc2, record.baidu_shared)

        print(sql_string)
        c.execute(sql_string)

        conn.commit()
        conn.close()

        return record

    def get_shared_info(self, search_num):
        conn = sqlite3.connect(self.db_filepath)
        c = conn.cursor()

        sql_string = "select baidu_shared from material where search_num=\"%s\";"%(search_num)

        print(sql_string)
        cursor = c.execute(sql_string)

        for row in cursor:
            return row[0]

        return ""

    def getUsedIds(self):
        conn = sqlite3.connect(self.db_filepath)
        c = conn.cursor()

        sql_string = "select id from material;"

        print(sql_string)
        cursor = c.execute(sql_string)

        idList = []
        for row in cursor:
            idList.append(row[0])

        conn.commit()
        conn.close()

        return idList
        
    def generate_id(self):
        usedIds = self.getUsedIds()
        return MaterialDao.get_unused_id(usedIds, 9999)

    @staticmethod
    def get_unused_id(usedIds, max_id):
        count = len(usedIds)
        left_count = max_id - count
        index_cache = random.randint(1, left_count)
        index = index_cache

        num = 0
        while index > 0 and num < max_id:
            num += 1
            if num not in usedIds:
                index = index - 1

        return num

    @staticmethod
    def generate_search_number(id, type_str):
        return '%s%d'%(type_str, id)

    