import os
import filesystem_helper
from PIL import Image
import json
import shutil


class Material:
    def __init__(self):
        self.psdFileInfo = filesystem_helper.FileInfo()
        self.picFileInfo = filesystem_helper.FileInfo()
        self.size = 0
        self.totalSize = 0  ##byte
        self.pixelWidth = 0
        self.pixelHeight = 0

    def isDispaly(self):
        arr = self.picFileInfo.rootDir.split("\\")
        subDir = ""
        for x in reversed(arr):
            if x.strip() != "":
                subDir = x
                break

        return subDir == "display"

    def cal_fileinfo(self):
        picPath = self.picFileInfo.getFullPath()
        img = Image.open(picPath)
        self.pixelWidth = img.size[0]
        self.pixelHeight = img.size[1]

        psdPath = self.psdFileInfo.getFullPath()
        size = os.path.getsize(psdPath)
        self.size = filesystem_helper.format_size(size)
        
        self.totalSize = self.totalSize + size
        self.totalSize = self.totalSize + os.path.getsize(picPath)
        
        #self.pixelWidth  = img.size #图片的长和宽

    def rename(self, filename, picFile):
        #rename psd
        src_filepath = self.psdFileInfo.getFullPath()
        dest_filepath = r"%s\%s"%(self.psdFileInfo.rootDir, filename)
        os.rename(src_filepath, dest_filepath)

        #rename pic
        src_filepath = self.picFileInfo.getFullPath()
        dest_filepath = r"%s\%s"%(self.picFileInfo.rootDir, picFile)
        os.rename(src_filepath, dest_filepath)

        self.psdFileInfo.rename(filename)
        self.picFileInfo.rename(picFile)


class MaterialDir:
    def __init__(self, dir_folder, material_type):
        self.dir_folder = dir_folder
        self.material_type = material_type
        self.dispMaterials = []
        self.otherMaterials = []
        self.totalSize = 0

    def rename(self, prefix):
        index = 0
        materials = self.dispMaterials + self.otherMaterials
        for material in materials:
            ext = material.psdFileInfo.ext
            extPic = material.picFileInfo.ext

            index = index + 1
            filename = r"%s_%03d%s"%(prefix, index, ext)
            picFile = r"%s_%03d%s"%(prefix, index, extPic)
            material.rename(filename, picFile)

    def analysis(self):
        print("dir_foler:%s, material_type:%s"%(self.dir_folder, self.material_type))
        
        dir_folder = self.dir_folder
        fileList = filesystem_helper.get_files(dir_folder, [self.material_type])

        for file_info in fileList:
            filename = file_info.filename 
            picFileInfo = filesystem_helper.find_file(file_info.rootDir, [".jpg", ".bmp", ".png"], filename)
            
            material_temp = Material()
            material_temp.psdFileInfo = file_info
            material_temp.picFileInfo = picFileInfo
            
            material_temp.cal_fileinfo()

            if material_temp.isDispaly():
                self.dispMaterials.append(material_temp)
            else:
                self.otherMaterials.append(material_temp)

            self.totalSize = self.totalSize + material_temp.totalSize

    def sort(self):
        self.sort_by_wh_rate()

    def sort_by_wh_rate(self):
        print("display count:%d"%(len(self.dispMaterials)))
        print("other count:%d"%(len(self.otherMaterials)))

        self.dispMaterials = sorted(self.dispMaterials, 
            key=lambda material_temp: material_temp.pixelWidth / material_temp.pixelHeight, 
            reverse=True)

        self.otherMaterials = sorted(self.otherMaterials, 
            key=lambda material_temp: material_temp.pixelWidth / material_temp.pixelHeight, 
            reverse=True)

    def addToPicGroup(self, picGroupList, arr_temp):
        topic = None
        if len(arr_temp) % 2 == 1:
            topic = arr_temp[0]
            arr_temp.pop(0)
        if topic is not None or len(arr_temp) != 0:
            picGroupList.append({
                "topic": topic,
                "arr": arr_temp
            })

    def groupby_scale(self):
        picGroupList = []
        arr_temp = []
        rate_befor = 0
        for material_temp in self.dispMaterials:
            rate = material_temp.pixelWidth / material_temp.pixelHeight
            if rate_befor == 0 or rate_befor - rate > 0.2:
                self.addToPicGroup(picGroupList, arr_temp)
                arr_temp = []
            
            arr_temp.append(material_temp)
            rate_befor = rate
        
        self.addToPicGroup(picGroupList, arr_temp)

        return picGroupList 

    def get_material_type(self):
        return self.material_type[1:]

    def get_pic_type(self):
        picFileExt = self.dispMaterials[0].picFileInfo.ext
        return picFileExt[1:]

    '''
    dict_info = {
        "srcDesc1": "日简繁 英文",
        "srcDesc2": "精选 字体",
        "srcNumber": "P123",
    }
    '''

    def getMaterialsCount(self):
        return len(self.dispMaterials) + len(self.otherMaterials)

    def output_json(self, filepath, recordJson):
        totalSize = filesystem_helper.format_size_2(self.totalSize)
        dict_data = {
            "srcCount": self.getMaterialsCount(),
            "srcSize": totalSize[0],
            "srcSizeUnit": totalSize[1],
            "materialCount": self.getMaterialsCount(),
            "fileCount": self.getMaterialsCount() * 2,
            "materialType": self.get_material_type(),
            "picType": self.get_pic_type(),
            "picGroupList": self.get_picgruop_list()
        }
        dict_data.update(recordJson)

        f = open(filepath, 'w', encoding='utf-8')
        jsonStr = json.dumps(dict_data, ensure_ascii = False)
        f.write(jsonStr)
        f.close()

    def copy_picfile_to(self, dest_dir):
        if not os.path.exists(dest_dir):
            os.mkdir(dest_dir)
            
        for material in self.dispMaterials:
            srcfile = material.picFileInfo.getFullPath()
            dstfile = r"%s\%s"%(dest_dir, material.picFileInfo.fullname)
            shutil.copyfile(srcfile, dstfile)
    
    def get_picgruop_list(self):
        picGroupList = []
        groupMaterList = self.groupby_scale()
        for temp in groupMaterList:
            picGroup = {}
            if temp["topic"] is not None:
                material = temp["topic"]
                picGroup["topic"] = {
                    "src": r"img/temp/%s"%(material.picFileInfo.fullname),
                    "desc": {
                        "filename": material.psdFileInfo.fullname,
                        "picsize": r"(%d*%d)像素"%(material.pixelWidth, material.pixelHeight),
                        "filesize": material.size
                    }
                }
            
            picGroup["arr"] = []
            for material in temp["arr"]:
                pic = {
                    "src": r"img/temp/%s"%(material.picFileInfo.fullname),
                    "desc": {
                        "filename": material.psdFileInfo.fullname,
                        "picsize": r"(%d*%d)像素"%(material.pixelWidth, material.pixelHeight),
                        "filesize": material.size
                    }
                }

                picGroup["arr"].append(pic)
            picGroupList.append(picGroup)

        return picGroupList


def rename(dirFolder, material_type, prefix):
    materialDir = MaterialDir(dirFolder, material_type)
    materialDir.analysis()
    materialDir.sort()
    materialDir.rename(prefix)

def output_json(dirFolder, dest_path, material_type, recordJson):
    materialDir = MaterialDir(dirFolder, material_type)
    materialDir.analysis()
    materialDir.output_json(dest_path, recordJson)

