import sys
import material_analysis 
import material_dao
import json
import img_helper
import os
import js_generator
import summary_generator
import shutil


db_path = "db"
data_temp_path = "data_temp"
data_temp_path_pic = "data_temp\\pic"
output_path = "output"
desc_pic_path = r"%s"%(output_path)
main_pic_path = r"%s"%(output_path)

def init_filesystem():
    if not os.path.exists(db_path):
        os.mkdir(db_path)
    if not os.path.exists(data_temp_path):
        os.mkdir(data_temp_path)
    if not os.path.exists(data_temp_path_pic):
        os.mkdir(data_temp_path_pic)
    if not os.path.exists(output_path):
        os.mkdir(output_path)
    if not os.path.exists(desc_pic_path):
        os.mkdir(desc_pic_path)
    if not os.path.exists(main_pic_path):
        os.mkdir(main_pic_path)
        

def do_rename():
    #rename D:\material_folder .psd liaow
    dirFolder = sys.argv[2]
    material_type = sys.argv[3]
    prefix = sys.argv[4]
    material_analysis.rename(dirFolder, material_type, prefix)

def do_output_json():
    #output_json D:\material_folder D:\export\main_pic.json .psd
    dirFolder = sys.argv[2]
    dest_path = sys.argv[3]
    material_type = sys.argv[4]
    record_path = r"%s/record.json"%(data_temp_path)
    f = open(record_path, 'r', encoding='utf-8')
    record_json = json.load(f)
    f.close()

    material_analysis.output_json(dirFolder, dest_path, material_type, record_json)

def do_insert_db():
    #insert_to_db D:\db\material.db D:\baidu_shared.txt 
    dbPath = r"%s\material.db"%(db_path)
    txtFilePath = sys.argv[2]

    shutil.copyfile(txtFilePath, r"%s\record.txt"%(data_temp_path))

    record = material_dao.MaterialRecord()
    record.load_from_txt(txtFilePath)
    
    dao = material_dao.MaterialDao(dbPath)
    dao.insert(record)

    record_path = r"%s/record.json"%(data_temp_path)
    record.save_to_json(record_path)

    #analysis size
    mainPicJsonPath = r"%s/main_pic.json"%(data_temp_path)
    materialDir = material_analysis.MaterialDir(record.srcFolder, record.srcExtType.lower())
    materialDir.analysis()
    materialDir.output_json(mainPicJsonPath, record.get_json_str())
    materialDir.copy_picfile_to(r"%s\img\temp"%(record.htmlPath))
    materialDir.copy_picfile_to(r"%s"%(data_temp_path_pic))

    savepath = r"%s/default_setting.js"%(record.htmlPath)
    js_generator.generate_main_pic(mainPicJsonPath, savepath)
    shutil.copyfile(savepath, r"%s\default_setting.js"%(data_temp_path))

    savepath = r"%s/detail_default_setting.js"%(record.htmlPath)
    js_generator.generate_desc_page(mainPicJsonPath, savepath)
    shutil.copyfile(savepath, r"%s\detail_default_setting.js"%(data_temp_path))

    do_save_summary(mainPicJsonPath)
    

def replace_html():
    record_path = r"%s/record.json"%(data_temp_path)
    savedir = ""
    js_generator.generate_main_pic(record_path, savedir)
    pass

def do_scale_pic():
    #dir = os.path.dirname(desc_pic_path)
    #main_pic = r"%s\main.png"%(dir)
    main_pic = sys.argv[2]
    desc_pic = sys.argv[3]
    scale = float(sys.argv[4])
    img_helper.resize(main_pic, scale)
    img_helper.resize(desc_pic, scale)

def do_split_desc_page_pic():
    src = sys.argv[2]
    dstpath = desc_pic_path
    split_by_type = "pixel"
    if split_by_type == "row":
        row = int(sys.argv[3])
        col = int(sys.argv[4])
        img_helper.split_image(src, row, col, dstpath)
    elif split_by_type == "pixel":
        width_px = int(sys.argv[3])
        height_px = int(sys.argv[4])
        img_helper.split_image_bypx(src, width_px, height_px, dstpath)

def do_save_summary(mainPicJsonPath):
    f = open(mainPicJsonPath, 'r', encoding='utf-8')
    setting = json.load(f)
    f.close()

    descPath = r"%s\\real_summary.html"%(output_path)
    summary = summary_generator.Summary()
    summary.fileCount = setting["srcCount"]
    summary.fileExt = setting["materialType"].upper()
    summary.picCount = setting["srcCount"]
    summary.totalSize = setting["srcSize"]
    summary.totalSizeType = setting["srcSizeUnit"]
    summary.style = setting["summaryStyle"]
    summary.generator(descPath)
    
def test_rename():
    sys.argv.append("rename")
    sys.argv.append(r"D:\baiduyun\素材\S2181（儿童 手绘 艺术 卡片 38款）")
    sys.argv.append(".ai")
    sys.argv.append("liaow")

def test_insert_to_db():
    sys.argv.append("insert_to_db")
    sys.argv.append(r"D:\learn_tech\taobao_tool\mfc_ui_exe\record.txt")

def test_split_desc_page_pic():
    sys.argv.append("split_desc_page_pic")
    sys.argv.append(r"D:\learn_tech\taobao_tool\mfc_ui_exe\output\desc.jpg")
    sys.argv.append("0")    #width
    sys.argv.append("400")  #height

def test_scale_pic():
    sys.argv.append("scale_pic")
    sys.argv.append(r"D:\learn_tech\taobao_tool\mfc_ui_exe\output\main.png")
    sys.argv.append(r"D:\learn_tech\taobao_tool\mfc_ui_exe\output\desc.png")
    sys.argv.append("0.5")    #scale

#test_rename()
#test_insert_to_db()
#test_split_desc_page_pic()
init_filesystem()
cmd = sys.argv[1]
print(sys.argv)

if cmd == "rename":
    do_rename()
elif cmd == "output_json":
    do_output_json()
elif cmd == "insert_to_db":
    do_insert_db()
elif cmd == "split_desc_page_pic":
    do_split_desc_page_pic()
elif cmd == "scale_pic":
    do_scale_pic()

    