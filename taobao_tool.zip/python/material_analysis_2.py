import os
import filesystem_helper
from PIL import Image
import json
import shutil


class PicFile:
    def __init__(self, fileInfo):
        self.fileInfo = fileInfo

        picPath = self.fileInfo.getFullPath()
        img = Image.open(picPath)
        self.pixelWidth = img.size[0]
        self.pixelHeight = img.size[1]

class MaterialDir:
    def __init__(self, dir_folder):
        self.dir_folder = dir_folder
        self.picList = []
        self.materialCount = 0
        self.totalSize = 0

    def analysis(self):
        dir_folder = self.dir_folder
        fileList = filesystem_helper.get_all_files(dir_folder)
        picExtList = [".jpg", ".bmp", ".png"]

        for file_info in fileList:
            extTemp = file_info.ext
            if extTemp in picExtList:
                self.picList.append(PicFile(file_info))
            else: 
                self.materialCount = self.materialCount + 1

            self.totalSize = self.totalSize + os.path.getsize(file_info.getFullPath())

        sort()

    def sort(self):
        self.picList = sorted(self.picList, 
            key=lambda picFileTemp: picFileTemp.pixelWidth / picFileTemp.pixelHeight, 
            reverse=True)

    def addToPicGroup(self, picGroupList, arr_temp):
        topic = None
        if len(arr_temp) % 2 == 1:
            topic = arr_temp[0]
            arr_temp.pop(0)
        if topic is not None or len(arr_temp) != 0:
            picGroupList.append({
                "topic": topic,
                "arr": arr_temp
            })

    def groupby_scale(self):
        picGroupList = []
        arr_temp = []
        rate_befor = 0
        for pic_temp in self.picList:
            rate = pic_temp.pixelWidth / pic_temp.pixelHeight
            if rate_befor == 0 or rate_befor - rate > 0.2:
                self.addToPicGroup(picGroupList, arr_temp)
                arr_temp = []
            
            arr_temp.append(pic_temp)
            rate_befor = rate
        
        self.addToPicGroup(picGroupList, arr_temp)

        return picGroupList 

    '''
    dict_info = {
        "srcDesc1": "日简繁 英文",
        "srcDesc2": "精选 字体",
        "srcNumber": "P123",
    }
    '''

    def output_json(self, filepath, recordJson):
        totalSize = filesystem_helper.format_size_2(self.totalSize)
        dict_data = {
            "srcCount": self.materialCount,
            "srcSize": totalSize[0],
            "srcSizeUnit": totalSize[1],
            "materialCount": self.materialCount,
            "fileCount": self.materialCount * 2,
            "picType": "jpg",
            "picGroupList": self.get_picgruop_list()
        }
        dict_data.update(recordJson)

        f = open(filepath, 'w', encoding='utf-8')
        jsonStr = json.dumps(dict_data, ensure_ascii = False)
        f.write(jsonStr)
        f.close()

    def copy_picfile_to(self, dest_dir):
        if not os.path.exists(dest_dir):
            os.mkdir(dest_dir)
            
        for picFileTemp in self.picList:
            srcfile = picFileTemp.fileInfo.getFullPath()
            dstfile = r"%s\%s"%(dest_dir, picFileTemp.fileInfo.fullname)
            shutil.copyfile(srcfile, dstfile)
    
    def get_picgruop_list(self):
        picGroupList = []
        groupMaterList = self.groupby_scale()
        for temp in groupMaterList:
            picGroup = {}
            if temp["topic"] is not None:
                material = temp["topic"]
                picGroup["topic"] = {
                    "src": r"img/temp/%s"%(material.picFileInfo.fullname),
                    "desc": {
                        "filename": material.psdFileInfo.fullname,
                        "picsize": r"(%d*%d)像素"%(material.pixelWidth, material.pixelHeight),
                        "filesize": material.size
                    }
                }
            
            picGroup["arr"] = []
            for material in temp["arr"]:
                pic = {
                    "src": r"img/temp/%s"%(material.picFileInfo.fullname),
                    "desc": {
                        "filename": material.psdFileInfo.fullname,
                        "picsize": r"(%d*%d)像素"%(material.pixelWidth, material.pixelHeight),
                        "filesize": material.size
                    }
                }

                picGroup["arr"].append(pic)
            picGroupList.append(picGroup)

        return picGroupList



