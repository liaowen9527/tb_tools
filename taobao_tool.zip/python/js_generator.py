import json

'''
(function(global_var){

function DefaultSetting(){
    this.imgList = new global_var.TablePicList();
    this.srcCount = 381;
    this.srcSize = 1.6;
    this.srcDesc1 = "日简繁 英文";
    this.srcDesc2 = "精选 字体";
    this.srcNumber = "P123";
}

global_var.DefaultSetting = DefaultSetting;

})(global_var);
'''


class MainPicJs:
    def __init__(self):
        pass

    def getPart1(self):
        return '''
            (function(global_var){

            function DefaultSetting(){
                this.imgList = new global_var.TablePicList();
        '''

    def getPart2(self):
        return '''
            }

            global_var.DefaultSetting = DefaultSetting;

            })(global_var);
        '''

    #["srcCount", "srcSize", "srcDesc1", "srcDesc2", "srcNumber"]
    def getPart3(self, filepath):
        f = open(filepath, 'r', encoding='utf-8')
        setting = json.load(f)
        f.close()

        return '''
        this.imgList = new global_var.TablePicList();
        this.srcCount = %d;
        this.srcSize = %s;
        this.srcSizeUnit = \"%s\";
        this.srcDesc1 = \"%s\";
        this.srcDesc2 = \"%s\";
        this.srcNumber = \"%s\";
        '''%(setting["srcCount"]
            , setting["srcSize"]
            , setting["srcSizeUnit"]
            , setting["srcDesc1"]
            , setting["srcDesc2"]
            , setting["srcNumber"])

    

class DescPageJs:
    def __init__(self):
        pass

    def getPart1(self):
        return '''
            (function(global_var){

            function DetailDefaultSetting(){
        '''

    def getPart2(self):
        return '''
            }

            global_var.DetailDefaultSetting = DetailDefaultSetting;

            })(global_var);
        '''

    #["srcCount", "srcSize", "srcDesc1", "srcDesc2", "srcNumber"]
    def getPart3(self, filepath):
        f = open(filepath, 'r', encoding='utf-8')
        setting = json.load(f)
        f.close()
        
        picGroupList = setting["picGroupList"]
        #jsonStr = json.dumps(picList, ensure_ascii=False, encoding='UTF-8') 
        jsonStr = json.dumps(picGroupList) 
        picName = "header_psd.png"
        materialType = setting["materialType"]
        desc2 = materialType.upper()
        if materialType == "ai" or materialType == "eps":
            picName = "header_ai.png"

        return '''
        this.picGroupList = new global_var.TopicTablePicList();
        this.picGroupList.setData(%s);
        this.header = {
            pic: \"img/%s\",
            desc1: \"(%d个文件/%s%s)\",
            desc2: \"(%s预览图)\"
        }
        '''%(jsonStr, picName
            , setting["srcCount"]
            , setting["srcSize"]
            , setting["srcSizeUnit"]
            , desc2)

def generate_main_pic(filepath, savepath):
    js = MainPicJs()
    str = js.getPart1() + js.getPart3(filepath) + js.getPart2()

    f = open(savepath, 'w', encoding='utf-8')
    f.write(str)
    f.close()

def generate_desc_page(filepath, savepath):
    js = DescPageJs()
    str = js.getPart1() + js.getPart3(filepath) + js.getPart2()

    f = open(savepath, 'w', encoding='utf-8')
    f.write(str)
    f.close()

