import os
from PIL import Image

#if dstpath == "", dstpath == the folder of orgin image's dir
def split_image(src, rownum, colnum, dstpath):
    img = Image.open(src)
    w, h = img.size
    if rownum <= h and colnum <= w:
        print('Original image info: %sx%s, %s, %s' % (w, h, img.format, img.mode))
        print('开始处理图片切割, 请稍候...')

        s = os.path.split(src)
        if dstpath == '':
            dstpath = s[0]
        fn = s[1].split('.')
        basename = fn[0]
        ext = fn[-1]

        num = 0
        rowheight = h // rownum
        colwidth = w // colnum
        for r in range(rownum):
            for c in range(colnum):
                box = (c * colwidth, r * rowheight, (c + 1) * colwidth, (r + 1) * rowheight)
                img.crop(box).save(os.path.join(dstpath, basename + '_' + str(num) + '.' + ext), img.format)
                num = num + 1

        print('图片切割完毕，共生成 %s 张小图片。' % num)
    else:
        print('不合法的行列切割参数！')


#if width_px == 0, per image's width == orgin image's width
#if height_px == 0, per image's height == orgin image's height
#if dstpath == "", dstpath == the folder of orgin image's dir
def split_image_bypx(src, width_px, height_px, dstpath):
    img = Image.open(src)
    w, h = img.size
    if height_px == 0:
        height_px = h
    if width_px == 0:
        width_px = w
    
    rownum = int(h / height_px)
    if h % height_px > 10:
        rownum += 1
    colnum = int(w / width_px)
    if w % width_px > 10:
        colnum += 1

    if rownum == 0 or colnum == 0:
        print('不合法的像素切割参数！')
        return

    print('Original image info: %sx%s, %s, %s' % (w, h, img.format, img.mode))
    print('开始处理图片切割, 请稍候...')

    s = os.path.split(src)
    if dstpath == '':
        dstpath = s[0]
    fn = s[1].split('.')
    basename = fn[0]
    ext = fn[-1]

    num = 0
    left_width = w
    left_height = h
    rowheight = 0
    colwidth = 0
    for r in range(rownum):
        rowheight = (height_px if left_height > height_px else left_height)
        left_height -= rowheight
        left_width = w

        for c in range(colnum):
            colwidth = (width_px if left_width > width_px else left_width)

            box = (c * width_px, r * height_px, c * width_px + colwidth, r * height_px + rowheight)
            num_temp = "%02d"%(num)
            img.crop(box).save(os.path.join(dstpath, basename + '_' + num_temp + '.' + ext), img.format)

            num = num + 1
            left_width -= colwidth

    print('图片切割完毕，共生成 %s 张小图片。' % num)
    
def resize(filepath, scale):
    img = Image.open(filepath)
    w, h = img.size
    w = int(w * scale)
    h = int(h * scale)
    out = img.resize((w, h))
    out.save(filepath)

def main():
    src = r"E:\code\html5\img\bg.jpg"
    dstpath = r""
    row = 2
    col = 3
    #split_image(src, row, col, dstpath)
    width_px = 300
    height_px = 400
    split_image_bypx(src, 0, height_px, dstpath)
