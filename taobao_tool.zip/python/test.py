import os
import json
import material_dao
import js_generator
import material_analysis


def test_generate_id():
    used_id = []
    max_id = 100
    count = max_id
    while count > 0:
        num = material_dao.MaterialDao.get_unused_id(used_id, max_id)
        used_id.append(num)
        count = count - 1

    used_id.sort()
    print(used_id)

def test_generate_mainpic_js():
    filepath = r"E:\code\taobao_tool\test_data\main_pic.json"
    savedir = r"E:\code\taobao_tool\test_data"

    js_generator.generate_main_pic(filepath, savedir)

def test_material_analysis():
    materialDir = material_analysis.MaterialDir(r"D:\learn_tech\taobao_tool\test_material", ".psd")
    materialDir.analysis()
    materialDir.rename("liaow")
    #materialDir.output_json(r"D:\learn_tech\taobao_tool\test_data\main_pic.json")

def test_record():
    recordTxt = r"D:\learn_tech\taobao_tool\mfc_ui\MaterialToolUi\MaterialToolUi\record.txt"
    record = material_dao.MaterialRecord()
    record.load_from_txt(recordTxt)

    dao = material_dao.MaterialDao("aaa.db")
    dao.insert(record)

    record_path = r"record.json"%()
    record.save_to_json(record_path)

    #analysis size
    mainPicJsonPath = r"main_pic.json"
    materialDir = material_analysis.MaterialDir(record.srcFolder, ".psd")
    materialDir.analysis()
    materialDir.output_json(mainPicJsonPath, record.get_json_str())

    savepath = r"default_setting.js"
    js_generator.generate_main_pic(mainPicJsonPath, savepath)

    savepath = r"detail_default_setting.js"
    js_generator.generate_desc_page(mainPicJsonPath, savepath)

#test_generate_mainpic_js()
print(os.path.splitext("/root/a.py"))
test_record()


    