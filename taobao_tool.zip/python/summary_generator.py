
import sys
import time

class Summary:
    def __init__(self):
        self.style = "果汁奶茶 饮品店 宣传单"
        self.fileCount = 63
        self.fileExt = "PSD"
        self.picCount = 63
        self.picExt = "jpg"
        self.totalSize = "12.9"
        self.totalSizeType = "GB"
        self.uploadTime = time.strftime("%Y-%m-%d")

    def generator(self, filepath):
        samplePath = "%s\\summary.html"%(sys.path[0])
        htmlf = open(samplePath, 'r', encoding="utf-8")
        htmlcont = htmlf.read()
        htmlf.close()

        new_htmlcont = htmlcont%(self.style, self.fileCount, self.fileExt, 
            self.picCount, self.picExt, self.totalSize, self.totalSizeType, self.uploadTime)
        
        newHtmlf = open(filepath, 'w', encoding="utf-8")
        newHtmlf.write(new_htmlcont)
        newHtmlf.close()



    