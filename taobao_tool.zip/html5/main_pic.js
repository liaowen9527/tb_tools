(function(global_var){

var app = angular.module('lw.ui');
app.controller('mainPicCtrl', function($scope, $timeout) {
    $scope.fixedSetting = function(){
        $scope.perPicWidth = "250";
        $scope.perPicHeight = "250";
        $scope.imgList = new global_var.TablePicList(2, 3, "img/bg.jpg");
        $scope.imgList.nRows = 3;
        $scope.imgList.nCols = 3;
        $scope.imgList.reinitPicList();

        $scope.previweImg = "";
        $scope.bgItems = [{
            bgColor: "red",
            pic: undefined,
            src: undefined
        }, {
            bgColor: "black",
            pic: undefined,
            src: undefined
        }];
        $scope.extItems = [{
            bgColor: "red",
            name: "ext1"
        }, {
            bgColor: "black",
            name: "ext2"
        }];
        $scope.waterItems = [{
            bgColor: "red",
            name: "watermark1"
        }, {
            bgColor: "black",
            name: "watermark2"
        }, {
            bgColor: "yellow",
            name: "watermark2"
        }];
        $scope.selectedIndexBg = 0;
        $scope.selectedIndexExt = 0;
        $scope.selectedIndexWater = 0;
    }

    $scope.defaultSetting = new global_var.DefaultSetting()
    $scope.copyDefaultSetting = function(){
        $scope.srcCount = $scope.defaultSetting.srcCount;
        $scope.srcSize = $scope.defaultSetting.srcSize;
        $scope.srcSizeUnit = $scope.defaultSetting.srcSizeUnit;
        $scope.srcDesc1 = $scope.defaultSetting.srcDesc1;
        $scope.srcDesc2 = $scope.defaultSetting.srcDesc2;
        $scope.srcNumber = $scope.defaultSetting.srcNumber;
    }

    $scope.fixedSetting();
    $scope.copyDefaultSetting();

    $scope.applySetting = function(){
        $scope.imgList.reinitPicList();
    }
    $scope.exportPic = function(){
        //var element = $("#main_pic_table")[0];
        //var element = $($("#main_pic_table").children().get(0))[0];
        var element = $("#main_pic_all")[0];
        var opt = {
            scale: 2
        }
        html2canvas(element, opt).then(function(canvas) {
            //var imgUri = canvas.toDataURL("image/png").replace("image/png", "image/octet-stream"); // 获取生成的图片的url
            //window.location.href = imgUri; // 下载图片
            //document.body.appendChild(canvas);
            $scope.previweImg = canvas.toDataURL("image/jpeg");
            $timeout(function(){
                $scope.previweImg = canvas.toDataURL("image/jpeg");
            }, 100);
        });
    }
    $scope.getBgStyle = function(){
        var picTable = $($("#main_pic_table").children().get(0));
        var pos = picTable.position();
        var offset = picTable.offset();
        if(!pos) return {};

        var w = picTable.width();
        var h = picTable.height();
        var bgItem = $scope.bgItems[$scope.selectedIndexBg];

        ret = {
            "position" : "absolute",
            "left" : pos.left + offset.left,
            "top" : pos.top + offset.top,
            "width" : w,
            "height" : h
        }

        if (bgItem.src) {
            var bgImg = "url(" + bgItem.src + ")";
            ret["background-image"] = bgImg;
        } else {
            ret["background"] = bgItem.bgColor;
        }
        
        //width: 600px; height: 600px; position: absolute; left: 0px; top: 0px;
        return ret;
    }
    $scope.getWaterStyle = function(){
        var picTable = $($("#main_pic_table").children().get(0));
        var pos = picTable.position();
        var offset = picTable.offset();
        if(!pos) return {};

        var w = picTable.width();
        var h = picTable.height();
        //width: 600px; height: 600px; position: absolute; left: 0px; top: 0px;
        return {
            "position" : "absolute",
            "left" : pos.left + offset.left,
            "top" : pos.top + offset.top,
            "width" : w,
            "height" : h
        };
    }
    $scope.getExtStyle = function(){
        var picTable = $($("#main_pic_table").children().get(0));
        var pos = picTable.position();
        var offset = picTable.offset();
        if(!pos) return {};

        var w = picTable.width() - 30;
        var h = picTable.height() - 30;
        //width: 600px; height: 600px; position: absolute; left: 0px; top: 0px;
        return {
            "position" : "absolute",
            "left" : pos.left + offset.left,
            "top" : pos.top + offset.top,
            "width" : w,
            "height" : h
        };
    }
    $scope.isShowWater = function(name){
        var waterItem = $scope.waterItems[$scope.selectedIndexWater];
        if(!waterItem) return false;

        return waterItem.name == name;
    }

    $scope.isShowExt= function(name){
        var extItem = $scope.extItems[$scope.selectedIndexExt];
        if(!extItem) return false;

        return extItem.name == name;
    }
    $scope.applyWater = function(){
        self.waterPic = null;
        var element = $("#water_pic")[0];
        html2canvas(element).then(function(canvas) {
            //var imgUri = canvas.toDataURL("image/png").replace("image/png", "image/octet-stream"); // 获取生成的图片的url
            //window.location.href = imgUri; // 下载图片
            //document.body.appendChild(canvas);
            $scope.waterPic = canvas.toDataURL("image/png");
            $timeout(function(){
                $scope.waterPic = canvas.toDataURL("image/png");
            }, 100);
        });
    }
    $scope.modifyWater = function(){
        self.waterPic = undefined;
        $timeout(function(){
            $scope.waterPic = undefined;
        }, 100);
    }
});

})(global_var);
