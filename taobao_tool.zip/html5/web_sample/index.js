angular.module('myApp',[])
    .directive('customTags',function(){
        return {
            restrict:'ECAM',
            templateUrl:'other.html', //用法1，以另一个页面为模板，注意相对路径是针对index.html的
            replace:true
        }
    })
    .directive('customTags2',function(){
        return {
            restrict:'ECAM',
            templateUrl:'customDiv2',   //用法2：以id="customDiv2"的元素为模板
            replace:true
        }
    })
    .controller('firstController',['$scope',function($scope){
        $scope.name='张三';
    }]);
