
            (function(global_var){

            function DefaultSetting(){
                this.imgList = new global_var.TablePicList();
        
        this.imgList = new global_var.TablePicList();
        this.srcCount = 25;
        this.srcSize = 183.32;
        this.srcSizeUnit = "MB";
        this.srcDesc1 = "儿童 卡通 卡片";
        this.srcDesc2 = "eps格式";
        this.srcNumber = "S792";
        
            }

            global_var.DefaultSetting = DefaultSetting;

            })(global_var);
        