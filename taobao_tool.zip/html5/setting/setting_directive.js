(function(global_var){

angular.module('lw.ui').directive('settingUi', SettingUIDirective);

SettingUIDirective.$inject = [];
function SettingUIDirective() {
    var directive = {
        restrict: 'E',
        templateUrl: 'setting/setting_template.html',
        link: linkFunc,
        controller: SettingUICtrl,
        scope: {
            perPicWidth: "=",
            perPicHeight: "=",
            picRows: "=",
            picCols: "=",
            imgList: "=",
            bgItems: "=",
            extItems: "=",
            waterItems: "=",
            selectedIndexBg: "=",
            selectedIndexExt: "=",
            selectedIndexWater: "="
        }
    };

    return directive;
    function linkFunc(scope, ele, attr, ctrl) {
    }
}

SettingUICtrl.$inject = [
    '$scope',
    '$timeout'
];

function SettingUICtrl($scope, $timeout) {
    var self = this;

    $scope.onImportPic = function(ele) {
        dataArr = { data : [] };
        fd = new FormData();
        var iLen = ele.files.length;

        var ctrlScope = this;
        var imgList = [];
        var picDataList = [];
        for(var i = 0; i < iLen; i++){	
            var reader = new FileReader();
            fd.append(i, ele.files[i]);
            reader.readAsDataURL(ele.files[i]);  //转成base64
            var fileName = ele.files[i].name;
    
            reader.onload = function(e){
                var imgMsg = {
                    name : fileName,//获取文件名
                    src : this.result   //reader.readAsDataURL方法执行完后，base64数据储存在reader.result里
                }
                
                imgList.push(imgMsg);
            }
        }

        //max wait 10s
        var nTimeout = 10000;
        function waitForLoad(){
            $timeout(function(){
                nTimeout = nTimeout - 100;
                if(imgList.length == iLen || nTimeout <= 0){
                    ctrlScope.imgList.reinitPicList();
                    ctrlScope.imgList.setImgList(imgList);
                } else {
                    waitForLoad();
                }
            }, 100);
        }
        waitForLoad();
    }
}

})(global_var);