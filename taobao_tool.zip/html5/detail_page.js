(function(global_var){

var app = angular.module('lw.ui');
app.controller('detailPageCtrl', function($scope, $timeout) {
    $scope.fixedSetting = function(){
        $scope.perPicWidth = "360";
        $scope.perPicHeight = "0";
        $scope.previweImg = "";
        $scope.detail_bg = "img/detail_bg.jpg"
        $scope.detail_water = "img/detail_water.png"
    }

    $scope.defaultSetting = new global_var.DetailDefaultSetting()
    $scope.copyDefaultSetting = function(){
        $scope.picGroupList = $scope.defaultSetting.picGroupList.build_data;
        $scope.header = $scope.defaultSetting.header;
    }

    $scope.fixedSetting();
    $scope.copyDefaultSetting();

    $scope.exportPic = function(){
        //var element = $("#main_pic_table")[0];
        //var element = $($("#main_pic_table").children().get(0))[0];
        var element = $("#main_pic_all")[0];
        var opt = {
            scale: 2
        }
        html2canvas(element, opt).then(function(canvas) {
            //var imgUri = canvas.toDataURL("image/png").replace("image/png", "image/octet-stream"); // 获取生成的图片的url
            //window.location.href = imgUri; // 下载图片
            //document.body.appendChild(canvas);
            $scope.previweImg = canvas.toDataURL("image/jpeg");
            $timeout(function(){
                $scope.previweImg = canvas.toDataURL("image/jpeg");
            }, 100);
        });
    }
    $scope.getBgStyle = function(){
        var picTable = $($("#main_pic_table").children().get(0));
        var pos = picTable.position();
        var offset = picTable.offset();
        if(!pos) return {};

        var bgImg = "url(" + $scope.detail_bg + ")";
        var w = picTable.width();
        var h = picTable.height();

        //width: 600px; height: 600px; position: absolute; left: 0px; top: 0px;
        return {
            "position" : "absolute",
            "left" : pos.left + offset.left,
            "top" : pos.top + offset.top,
            "width" : w,
            "height" : h,
            "background-image": bgImg,
            "background-repeat": "repeat"
        };
    }
    $scope.getBgStyle2 = function(){
        var bgImg = "url(" + $scope.detail_bg + ")";

        //width: 600px; height: 600px; position: absolute; left: 0px; top: 0px;
        return {
            "padding": "20px",
            "background-image": bgImg,
            "background-repeat": "repeat"
        };
    }
    $scope.getWaterStyle = function(){
        var picTable = $($("#main_pic_table").children().get(0));
        var pos = picTable.position();
        var offset = picTable.offset();
        if(!pos) return {};

        var bgImg = "url(" + $scope.detail_water + ")";
        var w = picTable.width();
        var h = picTable.height();
        //width: 600px; height: 600px; position: absolute; left: 0px; top: 0px;
        return {
            "position" : "absolute",
            "left" : pos.left + offset.left,
            "top" : pos.top + offset.top,
            "width" : w,
            "height" : h,
            "background-image": bgImg,
            "background-repeat": "repeat"
        };
    }
    $scope.getExtStyle = function(){
        var picTable = $($("#main_pic_table").children().get(0));
        var pos = picTable.position();
        var offset = picTable.offset();
        if(!pos) return {};

        var w = picTable.width() - 30;
        var h = picTable.height() - 30;
        //width: 600px; height: 600px; position: absolute; left: 0px; top: 0px;
        return {
            "position" : "absolute",
            "left" : pos.left + offset.left,
            "top" : pos.top + offset.top,
            "width" : w,
            "height" : h
        };
    }
    $scope.isShowWater = function(name){
        var waterItem = $scope.waterItems[$scope.selectedIndexWater];
        if(!waterItem) return false;

        return waterItem.name == name;
    }

    $scope.isShowExt= function(name){
        var extItem = $scope.extItems[$scope.selectedIndexExt];
        if(!extItem) return false;

        return extItem.name == name;
    }

    $timeout(function(){
        
    }, 500);
});

})(global_var);
