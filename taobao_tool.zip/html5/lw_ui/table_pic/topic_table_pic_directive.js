(function(global_var){

angular.module('lw.ui').directive('topicTablePicDirective', TopicTablePicDirective);

TopicTablePicDirective.$inject = [];
function TopicTablePicDirective() {
    var directive = {
        restrict: 'EA',
        //template: "<div>table_pic_template</div>",
        templateUrl: 'lw_ui/table_pic/topic_table_pic_template.html',
        link: linkFunc,
        controller: TopicTablePicCtrl,
        //controllerAs: 'tablePicScope',
        scope: {
            picWidth: "@",
            picHeight: "@",
            topicPicWidth: "@",
            topicPicHeight: "@",
            picGroupList: "="
        }
    };

    return directive;
    function linkFunc(scope, ele, attr, ctrl) {
    }
}

TopicTablePicCtrl.$inject = [
    '$scope',
    '$timeout'
];

function TopicTablePicCtrl($scope, $timeout) {
    var self = this;

    $scope.getImgStyle = function(){
        var ret = {}
        if ($scope.picWidth != "0px"){
            ret["width"] = $scope.picWidth;
        }
        if ($scope.picHeight && $scope.picHeight != "0px"){
            ret["height"] = $scope.picHeight;
        }
       
        return ret;
    }
    
    $scope.getTopicImgStyle = function(){
        var ret = {}
        if ($scope.topicPicWidth != "0px"){
            ret["width"] = $scope.topicPicWidth;
        }
        if ($scope.topicPicHeight && $scope.topicPicHeight != "0px"){
            ret["height"] = $scope.topicPicHeight;
        }

        ret["margin-top"] = "20px";
       
        return ret;
    }
}

})(global_var);