(function(global_var){

angular.module('lw.ui').directive('tablePicDirective', TablePicDirective);

TablePicDirective.$inject = [];
function TablePicDirective() {
    var directive = {
        restrict: 'EA',
        //template: "<div>table_pic_template</div>",
        templateUrl: 'lw_ui/table_pic/table_pic_template.html',
        link: linkFunc,
        controller: TablePicCtrl,
        //controllerAs: 'tablePicScope',
        scope: {
            picWidth: "@",
            picHeight: "@",
            picRows: "@",
            picCols: "@",
            picList: "="
        }
    };

    return directive;
    function linkFunc(scope, ele, attr, ctrl) {
    }
}

TablePicCtrl.$inject = [
    '$scope',
    '$timeout'
];

function TablePicCtrl($scope, $timeout) {
    var self = this;

    $scope.getImgStyle = function(){
        var ret = {}
        if ($scope.picWidth != "0px"){
            ret["width"] = $scope.picWidth;
        }
        if ($scope.picHeight && $scope.picHeight != "0px"){
            ret["height"] = $scope.picHeight;
        }
       
        return ret;
    }
    
    //$scope.picList = [];
    //$scope.reinitPicList($scope.picRows, $scope.picCols);
}

})(global_var);