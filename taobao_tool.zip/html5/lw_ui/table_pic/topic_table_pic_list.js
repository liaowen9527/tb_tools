(function(global_var){

function TopicTablePicList(nCol) {
    var self = this;
    nCol = nCol || 2;
    self.orgin_data = []
    self.build_data = []
    
    self.setData = function(data){
        self.orgin_data = data;
        self.buildData()
    }

    self.buildData = function(){
        self.build_data = [];
        
        self.orgin_data.forEach(picGroup => {
           picGroupNew = {} 
           picGroupNew["topic"] = picGroup["topic"];
           if(picGroup["arr"].length == 0) {
               self.build_data.push(picGroupNew);
               return;
           }

           picGroupNew["arr"] = [];
           var indexTemp = -1;
           for(var i = 0; i < picGroup["arr"].length; ++i) {
               var index = parseInt(i / nCol);
               var pic = picGroup["arr"][i];
               if(indexTemp != index){
                   picGroupNew["arr"].push([])
                   indexTemp = index;
               }
               picGroupNew["arr"][indexTemp].push(pic);
           }

           self.build_data.push(picGroupNew);
        });
    }

    self.defaultImg = function(){
        var ret = {
            src: self.defaultSrc
        };

        if(false){
            ret["desc"] = {
                filename: "轨迹素材_P123_21A",
                picsize: "(1920*1080)像素",
                filesize: "83.76MB"
            };
        }

        return ret;
    }

    
}

global_var.TopicTablePicList = TopicTablePicList;

})(global_var);
