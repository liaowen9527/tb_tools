(function(global_var){

function TablePicList(nRow, nCol, src) {
    var self = this;
    self.nRows = nRow || 2;
    self.nCols = nCol || 3;
    self.data = [];
    self.defaultSrc = src;

    self.defaultImg = function(){
        var ret = {
            src: self.defaultSrc
        };

        if(false){
            ret["desc"] = {
                filename: "轨迹素材_P123_21A",
                picsize: "(1920*1080)像素",
                filesize: "83.76MB"
            };
        }

        return ret;
    }

    self.reinitPicList = function(){
        self.reinitPicList2(self.nRows, self.nCols);
    }
    self.reinitPicList2 = function(row, col){
        while(self.data.length - row > 0){
            self.data.pop();
        }
        while(row - self.data.length > 0){
            var rowPicList = [];
            for(var i = 0; i < col; ++i){
                rowPicList.push(self.defaultImg());
            }
            self.data.push(rowPicList);
        }

        for(var i = 0; i < self.data.length; ++i){
            while(self.data[i].length - col > 0){
                self.data[i].pop();
            }
            while(col - self.data[i].length > 0){
                self.data[i].push(self.defaultImg());
            }
        }

        self.nRows = row;
        self.nCols = col;
    }

    self.setImg = function(index, img){
        row = parseInt(index / self.nCols);
        col = index % self.nCols;
        
        self.setImg2(row, col, img);
    }
    self.setImg2 = function(row, col, img){
        if(self.data.length <= row){
            return;
        }

        if(self.data[row].length <= col){
            return;
        }

        self.data[row][col] = img;
    }
    self.setImgList = function(imgList){
        for(var i = 0; i < imgList.length; ++i){
            self.setImg(i, imgList[i]);
        }
    }
    
    self.reinitPicList();
}

global_var.TablePicList = TablePicList;

})(global_var);
