(function(global_var){

angular.module('lw.ui').directive('selectableDiv', SelectableDivDirective);

SelectableDivDirective.$inject = [];
function SelectableDivDirective() {
    var directive = {
        restrict: 'EA',
        templateUrl: 'lw_ui/selectable_div/selectable_div_template.html',
        link: linkFunc,
        controller: SelectableDivPicCtrl,
        //controllerAs: 'tablePicScope',
        scope: {
            selectedIndex: "=",
            items: "="
        }
    };

    return directive;
    function linkFunc(scope, ele, attr, ctrl) {
    }
}

SelectableDivPicCtrl.$inject = [
    '$scope',
    '$timeout'
];

function SelectableDivPicCtrl($scope, $timeout) {
    var self = this;

    $scope.selectedIndex = $scope.selectedIndex || 0;

    $scope.onClick = function(index){
        $scope.selectedIndex = index;
    }
    
    $scope.getStyle = function(index){
        var border_style = "unset";
        if(index == $scope.selectedIndex){
            border_style = "solid";
        }

        var ret = {
            "margin" : "2px",
            "border-style" : border_style,
            "border-color" : "red"
        };
        
        var item = $scope.items[index];
        if(!item.pic){
            ret["width"] = "32px";
            ret["height"] = "32px";
            ret["background"] = item.bgColor;

            if(item.bgColor == "red"){
                ret["border-color"] = "green";
            }
        }

        return ret;
    }
    
    //$scope.picList = [];
    //$scope.reinitPicList($scope.picRows, $scope.picCols);
}

})(global_var);