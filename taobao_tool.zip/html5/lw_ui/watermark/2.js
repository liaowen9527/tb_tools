angular.module('lw.ui').directive('watermark2', Directive_2);

Directive_2.$inject = [];
function Directive_2() {
    var directive = {
        restrict: 'EA',
        templateUrl: 'lw_ui/watermark/2.html',
        link: linkFunc,
        controller: Ctrl_2,
        scope: {
            srcCount: "@",
            srcSize: "@",
            srcUnit: "@",
            srcDesc1: "@",
            srcDesc2: "@",
        }
    };

    return directive;
    function linkFunc(scope, ele, attr, ctrl) {
    }
}

Ctrl_2.$inject = [
    '$scope',
    '$timeout'
];

function Ctrl_2($scope, $timeout) {
    var self = this;
}