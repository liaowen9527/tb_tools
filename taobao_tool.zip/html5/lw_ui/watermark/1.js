angular.module('lw.ui').directive('watermark1', Directive_1);

Directive_1.$inject = [];
function Directive_1() {
    var directive = {
        restrict: 'EA',
        templateUrl: 'lw_ui/watermark/1.html',
        link: linkFunc,
        controller: Ctrl_1,
        scope: {
            srcCount: "@",
            srcSize: "@",
            srcUnit: "@",
            srcDesc1: "@",
            srcDesc2: "@",
        }
    };

    return directive;
    function linkFunc(scope, ele, attr, ctrl) {
    }
}

Ctrl_1.$inject = [
    '$scope',
    '$timeout'
];

function Ctrl_1($scope, $timeout) {
    var self = this;
}