angular.module('lw.ui').directive('ext2', ExtDirective_2);

ExtDirective_2.$inject = [];
function ExtDirective_2() {
    var directive = {
        restrict: 'EA',
        templateUrl: 'lw_ui/ext/2.html',
        link: linkFunc,
        controller: function(){},
        scope: {
            sourceNumber: "@"
        }
    };

    return directive;
    function linkFunc(scope, ele, attr, ctrl) {
    }
}

