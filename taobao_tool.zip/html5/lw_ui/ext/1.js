angular.module('lw.ui').directive('ext1', ExtDirective_1);

ExtDirective_1.$inject = [];
function ExtDirective_1() {
    var directive = {
        restrict: 'EA',
        templateUrl: 'lw_ui/ext/1.html',
        link: linkFunc,
        controller: ExtCtrl_1,
        scope: {
            sourceNumber: "@"
        }
    };

    return directive;
    function linkFunc(scope, ele, attr, ctrl) {
    }
}

function ExtCtrl_1($scope, $timeout) {
    var self = this;

    $scope.getStyle = function(w, h){
        str = "";
        //var template = "{0}px {1}px 1px black, ";
        for(var i = -w; i < w; ++i){
            for(var j = -h; j < h; ++j){
                str += i + "px " + j + "px 1px black,";
            }
        }
        str = str.substring(0, str.length - 1);
        return{
            "color": "white",
            "text-shadow": str,
            "font-size": "26"
        };
    }
    
    //$scope.picList = [];
    //$scope.reinitPicList($scope.picRows, $scope.picCols);
}
