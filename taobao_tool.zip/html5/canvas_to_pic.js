(function(global_var){

function CanvasToPic(){
    var self = this;
    this.retImgData = "";
    
    self.exportPic = function(element){
        //var element = $("#main_pic_all")[0];
        var opt = {
            scale: 2
        }
        html2canvas(element, opt).then(function(canvas) {
            self.retImgData = canvas.toDataURL("image/png");
        });
    }

    /**
     * 在本地进行文件保存
     * @param  {String} data     要保存到本地的图片数据
     * @param  {String} filename 文件名
     */
    self.saveFile = function(data, filename){
        var save_link = document.createElementNS('http://www.w3.org/1999/xhtml', 'a');
        save_link.href = data;
        save_link.download = filename;

        var event = document.createEvent('MouseEvents');
        event.initMouseEvent('click', true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
        save_link.dispatchEvent(event);
    };

    self.saveCanvasToDisk = function(canvas, filename){        
        var image = canvas.toDataURL('image/png').replace('image/png', 'image/octet-stream');
        self.saveFile(image, filename || 'file_' + new Date().getTime() + '.png');
    }
}

global_var.CanvasToPic = CanvasToPic;

})(global_var);
