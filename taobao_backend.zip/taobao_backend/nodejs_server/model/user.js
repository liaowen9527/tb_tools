function Vip(){
    this.vip = "vip";
    this.svip = "svip";
}

function User() {
    this.username = "";
    this.password = "";
    this.register_time = "";
    this.vip = "vip";
}

module.exports = User;
module.exports = Vip;