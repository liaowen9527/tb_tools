function LoginHistory(){

}

module.exports = LoginHistory;