function Purchase() {
    this.username = "";
    this.material = "";
    this.time_ = null;
}

module.exports = Purchase;