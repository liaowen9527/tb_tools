$.ajaxSetup({
    complete: function (xhr, status, error) {
    },
	timeout: 60000
});

function VmoreHttp() {
    var server = "http://localhost:8888/";

    this.http_get = function(url, data) {
        var defer = $.Deferred();
        $.ajax({
            type: 'GET',
            url: url,
            data: data,
            success: function(result, status, xhr) {
                if (!result.result && result.redirect) {
                    window.location.href = result.redirect;
                    defer = null;
                } else {
                    defer.resolve(result);
                }
            },
            error: function(xhr, status, error){
                defer.reject(status);
            }
          });
        return defer;
    }
    this.http_post = function(url, data) {
        var defer = $.Deferred();
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            success: function(result, status, xhr) {
                if (!result.result && result.redirect) {
                    window.location.href = result.redirect;
                    defer = null;
                } else {
                    defer.resolve(result);
                }
            },
            error: function(xhr, status, error){
                defer.reject(status);
            }
          });
        return defer;
    }

    this.verify_captcha = function(code) {
        var url = server + "verify_captcha/" + code;

        return this.http_get(url);
    }
    this.get_captcha_url = function() {
        return server + "captcha";
    }
    this.user_login = function(username, password) {
        var url = server + "user/login";
        var data = {
            username: username,
            password: password
        }

        return this.http_post(url, data);
    }
    this.user_logout = function() {
        var url = server + "user/logout";

        return this.http_post(url);
    }
    this.get_material = function(id) {
        var url = server + "material/query/" + id;

        return this.http_get(url);
    }
    this.purchase_today_history = function(){
        var url = server + "material/today_history";

        return this.http_get(url);
    }
    this.get_purchase_count = function(){
        var url = server + "material/count";

        return this.http_get(url);
    }
}

window.VmoreHttp = VmoreHttp;