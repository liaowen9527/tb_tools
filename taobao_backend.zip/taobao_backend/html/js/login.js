
function LoginCtrl () {
    var ctrl = this;
    this.bSuccVerifyCaptcha = false;
    this.http = new window.VmoreHttp();

    this.OnClickCaptchaImg = function(){
        var verifyimg = $('#vercode_img').attr('src');
        verifyimg = verifyimg.split("?")[0];
        $('#vercode_img').attr('src', verifyimg + '?random=' + Math.random());	
    }

    this.OnChangeInputCaptcha = function(){
        if($('#vercode_txt').val().length <= 2){
            return;
        }

        ctrl.http.verify_captcha($('#vercode_txt').val()).then(
            function(result){
                if(result.result){
                    ctrl.showVerifyCaptcha(true);
                }else{						
                    ctrl.showVerifyCaptcha(false);
                    if (result.errcode == 1) {
                        //session changed, refresh the captcha
                        ctrl.OnClickCaptchaImg();
                    }
                }
            }, function(err){
                ctrl.showVerifyCaptcha(false);
            }
        );
    }

    this.OnLogin = function() {
        if (!ctrl.bSuccVerifyCaptcha) {
            ctrl.showVerifyCaptcha(false);
            return false;
        }

        var username = $("#user").val();
        var password = $("#pass").val();
        function OnFailedLogin(){
            //refresh the captcha
            ctrl.OnClickCaptchaImg();
            $("#vercode_txt").val("");
            $(".pass").css("display","block");
            ctrl.showVerifyCaptcha(false, true);
        }

        ctrl.http.user_login(username, password).then(function(result){
            if(!result.result) {
                OnFailedLogin();
                return false;
            }
            //alert("login succeed.");
            ctrl.cacheUserData(result);
            window.location.href = "welcome.html";
        }, function(err){
            OnFailedLogin();
        });

        return false;
    }

    this.isSuccVerifyCaptcha = function(){
        return ctrl.bSuccVerifyCaptcha;
    }
    this.showVerifyCaptcha = function(result, hideall){
        ctrl.bSuccVerifyCaptcha = result;
        if (hideall) {
            $(".yes").css("display","none");
            $(".no").css("display","none");
        } else {
            if(result){
                $(".yes").css("display","block");
                $(".no").css("display","none");
            } else {
                $(".yes").css("display","none");
                $(".no").css("display","block");
            }
        }
    }
    this.cacheUserData = function(user) {
        document.cookie = JSON.stringify(user);
    }
}

function RegisterEvent(ctrl) {
    $("#vercode_img").click(ctrl.OnClickCaptchaImg);
    $("#vercode_txt").bind('input propertychange', ctrl.OnChangeInputCaptcha);
}

layui.use('table', function(){
    var table = layui.table, 
    form = layui.form;

    var ctrl = new LoginCtrl();
    RegisterEvent(ctrl);
     
     
    //pass 
    $("#pass").blur(function(){
        $(".pass").css("display","none");
    }); 
     
     //表单
    form.on('submit(login)', ctrl.OnLogin);
 });

