(function(global_var){

angular.module('lw.ui').directive('loginUi', LoginUIDirective);

LoginUIDirective.$inject = [];
function LoginUIDirective() {
    var directive = {
        restrict: 'E',
        templateUrl: 'login.html',
        link: linkFunc,
        controller: LoginUICtrl,
        scope: {
            username: "="
        }
    };

    return directive;
    function linkFunc(scope, ele, attr, ctrl) {
    }
}

LoginUICtrl.$inject = [
    '$scope',
    '$timeout'
];

function LoginUICtrl($scope, $timeout) {
    var self = this;

    
}

})(global_var);