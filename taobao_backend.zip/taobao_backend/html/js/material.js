function MaterialCtrl(layui) {
    var ctrl = this;
    this.http = new window.VmoreHttp();
    this.layui = layui;
    var userInfo = JSON.parse(document.cookie);

    this.OnLogout = function(){
        layer.confirm('要退出登陆吗？', {icon: 3, title:'提示'}, function(index9) {
            ctrl.http.user_logout().then(function(result) {
                //window.location.reload();
                window.location.href = "login.html";
            }, function(err) {
                
            });
            layer.close(index9);
        });
    }
    this.OnQuery = function() {
        var materialId = $("#q_datas").val();
        function OnResult(info, clean_input) {
            layer.alert(info, {
                skin: 'layer-ext-moon'  
                ,closeBtn: 0
                ,area: '550px'
            });

            if(clean_input){
                $("#q_datas").val("");
            }
        }
        ctrl.http.get_material(materialId).then(function(result){
            if(result.result){
                OnResult(result.cur_material.baidu_shared, true);
                ctrl.DisplayLimitInfo(result.limit_count);
                ctrl.DisplayHistory();
            } else {
                OnResult(result.reason);
            }
        }, function(err){
            OnResult('您输入的编号有误.');
        });

        return false;
    }
    this.InitUi = function() {
        this.DisplayStaticInfo();
        this.DisplayDynamicInfo();
    }
    this.DisplayHistory = function() {
        ctrl.http.purchase_today_history().then(function(result){
            if(!result.result || result.dataList.length < 1){
                return;
            }
            var html_info = '<div class="list"><div>······················ 今天取货记录 ·······················</div>';
            for (var i = 0; i < result.dataList.length; ++i) {
                var record = result.dataList[i];
                html_info = html_info + record.baidu_shared + '<br>';
            }
            html_info = html_info + '</div>';
            $(".list").html(html_info);
        }, function(err){

        });
    }
    this.DisplayStaticInfo = function() {
        var html_info = '<div class="userinfobox">您好 <b>' + userInfo.username + '</b>，会员等级是 <span>' + userInfo.vip + '</span><i id="logout">退出登陆</i></div>';
        $(".userinfobox").html(html_info);

        //<div id="vip_tip">您是<b>SVIP</b><br><b class="b1">取货次数</b>不限制<br><b class="b1">素材类别</b>不限制<br></div><br></div>
        var limitStr = '不限制';
        if (userInfo.limitTotal && userInfo.limitTotal > 0) {
            limitStr = userInfo.limit_total;
        }

        var limitType = '不限制';
        if (userInfo.limit_type && userInfo.limit_type.length > 0) {
            limitType = userInfo.limit_type.join(',');
        }

        var html_info = '<div id="vip_tip">您是<b>' + userInfo.vip + '</b><br><b class="b1">取货次数</b>' + limitStr + '<br><b class="b1">素材类别</b>' + limitType + '<br></div>';
        $("#vip_tip").html(html_info);
    }
    this.DisplayDynamicInfo = function() {
        ctrl.http.get_purchase_count().then(function(purchase_count){
            var limit_count = {limit_day: -1, limit_week: -1, limit_total: -1}
            if (userInfo.limit_day >0) {
                limit_count.limit_day = userInfo.limit_day - purchase_count.limit_day;
            }
            if (userInfo.limit_week >0) {
                limit_count.limit_week = userInfo.limit_week - purchase_count.limit_week;
            }
            if (userInfo.limit_total >0) {
                limit_count.limit_total = userInfo.limit_total - purchase_count.limit_total;
            }

            ctrl.DisplayLimitInfo(limit_count);
        });

        this.DisplayHistory();
    }
    this.DisplayLimitInfo = function(limit_count){
        var html_info = '<span class="info">今天取货个数剩余<b>' + limit_count.limit_day + '</b>个，本周剩余<b>' + limit_count.limit_week + '</b>个</span>';
        $(".info").html(html_info);
    }
    this.RegisterEvent = function() {
        var table = ctrl.layui.table, 
        form = ctrl.layui.form;

        $("#logout").click(ctrl.OnLogout);
        form.on('submit(getscid)', ctrl.OnQuery);
    }

    this.InitUi();
}



layui.use('table', function(){
    var ctrl = new MaterialCtrl(layui);
    ctrl.RegisterEvent();
})