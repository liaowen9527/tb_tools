<?php
require_once('../admin_sc/conf_ini.php');
require_once('../function/function.php');
session_start();

//■■■■■■■■■■■■■■■■■■■■■■■■■■■ 验证码AJAX ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
if( isset($_GET["yzm_code"]) && !empty($_GET["yzm_code"]) ){
	//验证码对比
	if( strcasecmp($_GET["yzm_code"],$_SESSION["captcha_sc"])==0 ){
		exit("1");
	}else{
		exit("0");
	}
}
//■■■■■■■■■■■■■■■■■■■■■■■■■■■ 登陆 ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
if(@!preg_match("/^\d+$/",$_SESSION["vid"]) && @$_POST["user"] && @$_POST["pass"] && @$_POST["code"]){
	//验证码
	if( strcasecmp(@$_POST["code"],@$_SESSION["captcha_sc"])!=0 ) exit("yzm_error");
	//N次密码错误封IP
	if(banip($passerror_count)) exit("ip_error|密码错误次数过多,请过一段时间才尝试！");
	//POST 过滤
	$user = safe_replace( preg_replace("/\s+/",'',$_POST["user"]) );
	$pass = safe_replace( preg_replace("/\s+/",'',$_POST["pass"]) );
	//重查询
	$sql = 'SELECT * FROM viplist WHERE taoid="'.$user.'" AND pass="'.$pass.'"';
	$vip_data = $conn->query($sql);
	if ($vip_data->num_rows == 1) {
		$vip_data = $vip_data->fetch_assoc();
	}else{
		$vip_data='';
	}
	
	//验证
	if( $vip_data!='' && $vip_data["taoid"]==trim($_POST["user"]) && $vip_data["pass"]==trim($_POST["pass"]) ){
		//是否被禁用
		if($vip_data["ban"]!='enable'){
			//log
			@$conn->query('INSERT INTO log(logtype, safety, info, ipaddress, logdate) VALUES ("login","no","【禁止登陆】已禁止['.$user.']的登陆！","'.$_SERVER["REMOTE_ADDR"].'","'.date("Y-m-d H:i:s").'")');
			exit('ban|<b class="msg">您的账号异常</b>'); 
		}
		//验证通过
		session_unset();
		session_destroy();
		session_start();
		$_SESSION["vid"] = $vip_data["vid"];  //认证
		$_SESSION["taoid"] = $vip_data["taoid"];  //认证
		$_SESSION["vlevel"] = $vip_data["vlevel"];  //认证
		$up_sql = 'UPDATE viplist SET online="'.session_id().'|'.$_SERVER["REMOTE_ADDR"].'|'.(time()+$out_login_time).'" WHERE vid="'.$_SESSION["vid"].'"'; //唯一身份 
		$conn->query($up_sql);
		//log
		@$conn->query('INSERT INTO log(logtype, safety, info, ipaddress, logdate) VALUES ("login","yes","【登陆成功】'.$user.' 登陆！","'.$_SERVER["REMOTE_ADDR"].'","'.date("Y-m-d H:i:s").'")');
		exit("dlcg");
	}else{
		//log
		@$conn->query('INSERT INTO log(logtype, safety, info, ipaddress, logdate) VALUES ("login","no","【密码错误】用户名：'.$user.' 密码：'.$pass.'","'.$_SERVER["REMOTE_ADDR"].'","'.date("Y-m-d H:i:s").'")');
		exit("pass_error");
	}
	
}


//■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■  【取货流程验证】  ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■


if(@preg_match("/^\d+$/",$_SESSION["vid"]) && @$_POST["mode"]=='getlist' && isset($_POST["q_datas"]) ){

	$query_datas = preg_split("/\s+/",trim($_POST["q_datas"]));
	
	//一次不能多余5个
	$query_count = count($query_datas);
	if( $query_count > $one_query_num )  exit('error|<b class="msg">每次不能超过<b>'.$one_query_num.'</b>个</b>');
	
	//检查素材编码格式
	foreach($query_datas as $val){
		if(!preg_match("/^\w+$/",$val)) exit('error|<b class="msg"><b>'.$val.'</b> 素材编号错误！</b>');
		if( @!empty($scids) ) $scids.=',';
		@$scids.='"'.$val.'"';
	}
	
	//【确认登陆状态，认证成功返回VIP信息】
	$vip_data = online_check();
	
	//账户是否禁用
	if($vip_data["ban"]!='enable'){
		session_unset();
		session_destroy();
		exit('loguot|<b class="logout">检测到账号异常</b>'); 
	}
	
	//VIP个数限制
	if($vip_data["vlevel"]=='vip'){
		
		$date=date("Y-m-d");
		$date7 = date("Y-m-d",strtotime("-6 day"));
		$sql_1 = 'SELECT * FROM loglist WHERE vid='.$_SESSION["vid"].' AND logtime between "'.$date.' 00:00:00" and "'.$date.' 23:59:59"' ;
		$sql_7 = 'SELECT * FROM loglist WHERE vid='.$_SESSION["vid"].' AND logtime between "'.$date7.' 00:00:00" and "'.$date.' 23:59:59"' ;

		$qh_list_1 = $vip_day_num - ($conn->query($sql_1))->num_rows;  // 天剩余个数
		$qh_list_7 = $vip_week_num - ($conn->query($sql_7))->num_rows; // 周剩余个数
		if( $qh_list_7 < $qh_list_1 )   $qh_list_1 = $qh_list_7;  //天剩余个数不能超过 周限额
		
		if($qh_list_1<=0) exit('error|<b class="msg">今天取货次数用完啦！<br>可升级<b>SVIP</b>取货不限制</b>');
		elseif($query_count > $qh_list_1) exit('error|<b class="msg">今天剩余取货数不足<b>'.$query_count.'</b>个</b>');
	//临时代码！！！！！
	}else{
		
		$date=date("Y-m-d");
		$date7 = date("Y-m-d",strtotime("-6 day"));
		$sql_1 = 'SELECT * FROM loglist WHERE vid='.$_SESSION["vid"].' AND logtime between "'.$date.' 00:00:00" and "'.$date.' 23:59:59"' ;
		$sql_7 = 'SELECT * FROM loglist WHERE vid='.$_SESSION["vid"].' AND logtime between "'.$date7.' 00:00:00" and "'.$date.' 23:59:59"' ;

		$qh_list_1 = 30 - ($conn->query($sql_1))->num_rows;  // 天剩余个数
		$qh_list_7 = 130 - ($conn->query($sql_7))->num_rows; // 周剩余个数
		if( $qh_list_7 < $qh_list_1 )   $qh_list_1 = $qh_list_7;  //天剩余个数不能超过 周限额
		
		if($qh_list_1<=0) exit('error|<b class="msg">SVIP调整中~ 3天左右恢复正常  如果您急用素材 可联系店主 </b>');
		elseif($query_count > $qh_list_1) exit('error|<b class="msg">SVIP调整中~3天左右恢复正常 如果您急用素材 可联系店主</b>');
		
	}
	
	
	//取货 +  SVIP专用素材 + 记录
	$sql_query = 'SELECT * FROM sclist  WHERE scid IN('.$scids.')';
	$sc_date = $conn->query($sql_query);
	if ($sc_date->num_rows > 0) {
		while($row = $sc_date->fetch_assoc()) {
			//【禁用素材】
			if($row["display"]!='enable')  exit('error|<b class="msg"><b>'.$row["scid"].'</b>暂时没录入，请等待更新</b>');
			//【VIP不能取SVIP素材】
			if($vip_data["vlevel"]=='vip' && $row["slevel"]=='svip') exit('error|<b class="msg"><b>'.$row["scid"].'</b>是<b>SVIP</b>素材<br>您的等级是VIP</b>');
			//返回html
			@$sc_date_list.=$row["scid"].' '.$row["down_add"].'<br>';
			//写入取货记录
			if( @!empty($insert_log_sql) ) $insert_log_sql.=',';
			@$insert_log_sql.='('.$vip_data["vid"].','.$row["sid"].',"'.date("Y-m-d H:i:s").'")';
		}
		
		$insert_log_sql='INSERT INTO loglist(vid,sid,logtime) VALUES'.$insert_log_sql;
		if ($conn->query($insert_log_sql) === TRUE){
			//log
			@$conn->query('INSERT INTO log(logtype, safety, info, ipaddress, logdate) VALUES ("query","yes","【取货成功】ID：'.$_SESSION["taoid"].' 取货成功！","'.$_SERVER["REMOTE_ADDR"].'","'.date("Y-m-d H:i:s").'")');
			exit($sc_date_list);
		}else{
			//log
			@$conn->query('INSERT INTO log(logtype, safety, info, ipaddress, logdate) VALUES ("query","no","【取货失败】ID：'.$_SESSION["taoid"].' 取货记录插入错误！","'.$_SERVER["REMOTE_ADDR"].'","'.date("Y-m-d H:i:s").'")');
			exit('error|数据库错误，请联系管理员！');
		}
			
	}else{
		exit('error|<b class="msg">素材<b>'.$_POST["q_datas"].'</b>不存在，<br>请检查编号或等待更新...</b>');
	}
	
}


//■■■■■■■■■■■■■■■■■■■■■■■■■■■ 取货次数  ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
if(@preg_match("/^\d+$/",$_SESSION["vid"]) &&  @$_GET["mode"]=='userinfo' ){
	
	if($_SESSION["vlevel"]=='vip'){
		//日期计算
		$date=date("Y-m-d");
		$date7 = date("Y-m-d",strtotime("-6 day"));
		
		$sql_1 = 'SELECT * FROM loglist WHERE vid='.$_SESSION["vid"].' AND logtime between "'.$date.' 00:00:00" and "'.$date.' 23:59:59"' ;
		$sql_7 = 'SELECT * FROM loglist WHERE vid='.$_SESSION["vid"].' AND logtime between "'.$date7.' 00:00:00" and "'.$date.' 23:59:59"' ;
		$qh_list_1 = $vip_day_num - ($conn->query($sql_1))->num_rows;
		$qh_list_7 = $vip_week_num - ($conn->query($sql_7))->num_rows;
		if( $qh_list_7 < $qh_list_1 )	$qh_list_1 = $qh_list_7; //当天取货 不能超过周限额
		if( $qh_list_1 <0 ) $qh_list_1 = 0;  //为负数 则设0
		if( $qh_list_7 <0 ) $qh_list_7 = 0;  //为负数 则设0
		
		$info_html='今天取货个数剩余<b>'.$qh_list_1.'</b>个，本周剩余<b>'.$qh_list_7.'</b>个';
		exit($info_html);
	}elseif($_SESSION["vlevel"]=='svip'){
		exit("今天取货个数剩余<b>999</b>个，本周剩余<b>999</b>个");
	}
}

//■■■■■■■■■■■■■■ 取货记录 ■■■■■■■■■■■■■■■■■■■■■
	if(@preg_match("/^\d+$/",$_SESSION["vid"]) && @$_GET["mode"]=='daylist'){
		$sql = 'SELECT b.scid,b.title,b.down_add FROM loglist a LEFT JOIN sclist b ON a.sid=b.sid WHERE a.vid='.$_SESSION["vid"].' AND a.logtime between "'.date("Y-m-d").' 00:00:00" and "'.date("Y-m-d").' 23:59:59" ORDER BY a.logtime DESC' ;
		$day_sc_list = $conn->query($sql);
		$day_sc_list_html = '<div>······················ 今天取货记录 ·······················</div>';
		if($day_sc_list->num_rows > 0){
			while($row = $day_sc_list->fetch_assoc()) {
				$day_sc_list_html.=$row["scid"].' '.$row["down_add"].'<br>';
			}
			exit($day_sc_list_html);
		}
	}
//■■■■■■■■■■■■■■ 退出登陆 ■■■■■■■■■■■■■■■■■■■■■
	if(@preg_match("/^\d+$/",$_SESSION["vid"]) && @$_GET["mode"]=='logout'){
		session_unset();
		session_destroy();
	}
?>