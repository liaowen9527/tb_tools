<?php 
require_once('../admin_sc/conf_ini.php');
session_start();

if(@preg_match("/^\d+$/",$_SESSION["vid"])){
	//查询数据库
	$sql = 'SELECT * FROM viplist WHERE vid="'.$_SESSION["vid"].'"';
	$vip_data = $conn->query($sql);
	if ($vip_data->num_rows == 1) {
		$vip_data = $vip_data->fetch_assoc();
	}else{
		@$conn->query('INSERT INTO log(logtype, safety, info, ipaddress, logdate) VALUES ("syserror","no","【数据错误】VID：'.$_SESSION["vid"].' 页面刷新重新认证SESSION_VID为空或存在多个","'.$_SERVER["REMOTE_ADDR"].'","'.date("Y-m-d H:i:s").'")');
		session_unset();
		session_destroy();
		exit();
	}
	
	//更新SESSION
	$_SESSION["vlevel"] = $vip_data["vlevel"];
	$_SESSION["taoid"] = $vip_data["taoid"];
	
	//禁用
	if($vip_data["ban"]!='enable'){
		session_unset();
		session_destroy();
		exit();
	}
	
	//唯一身份校验
	$login_inof = explode("|",$vip_data["online"]);
	if( $login_inof[0]==session_id() && $login_inof[1]==$_SERVER["REMOTE_ADDR"] && $login_inof[2]>time() ){
		$up_sql = 'UPDATE viplist SET online="'.$login_inof[0].'|'.$login_inof[1].'|'.(time()+$out_login_time).'" WHERE vid="'.$_SESSION["vid"].'"';
		$conn->query($up_sql);
	}else{
		session_unset();
		session_destroy();
	}
}else{
	session_unset();
	session_destroy();
}


?>