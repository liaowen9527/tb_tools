<?php 
//过滤函数
function safe_replace($string) {
    $string = str_replace('%20','',$string);
    $string = str_replace('%27','',$string);
    $string = str_replace('%2527','',$string);
    $string = str_replace('*','',$string);
    $string = str_replace('"','&quot;',$string);
    $string = str_replace("'",'',$string);
    $string = str_replace('"','',$string);
    $string = str_replace(';','',$string);
    $string = str_replace('<','&lt;',$string);
    $string = str_replace('>','&gt;',$string);
    $string = str_replace("{",'',$string);
    $string = str_replace('}','',$string);
    $string = str_replace('\\','',$string);
    return $string;
}




//当天登陆X次错误封IP 1天
function banip($x){
	$sql='SELECT count(*) as count FROM log WHERE logtype="login" AND safety="no" AND  ipaddress="'.$_SERVER["REMOTE_ADDR"].'" AND logdate between "'.date("Y-m-d").' 00:00:00" and "'.date("Y-m-d").' 23:59:59"';
	global $conn;
	$error_count = ($conn->query($sql))->fetch_assoc();
	if( $error_count["count"] >= $x )
		return 1;
	else
		return 0;
}




//登陆状态检查
function online_check(){
	global $out_login_time;
	global $conn;
	//查询数据
	$sql = 'SELECT * FROM viplist WHERE vid="'.$_SESSION["vid"].'"';
	$vip_data = $conn->query($sql);
	
	if ($vip_data->num_rows == 1) {
		$vip_data = $vip_data->fetch_assoc();
	}else{
		@$conn->query('INSERT INTO log(logtype, safety, info, ipaddress, logdate) VALUES ("syserror","no","【数据错误】VID：'.$_SESSION["vid"].' 取货时重新认证SESSION_VID为空或存在多个","'.$_SERVER["REMOTE_ADDR"].'","'.date("Y-m-d H:i:s").'")');
		session_unset();
		session_destroy();
		exit('error|数据错误');
	}
	
	//更新等级信息
	$_SESSION["vlevel"] = $vip_data["vlevel"];  
	
	//提取 认证信息 数据
	$login_inof = explode("|",$vip_data["online"]);
	
	//与登陆时身份校验 成功返回数组
	if( $login_inof[0]==session_id() && $login_inof[1]==$_SERVER["REMOTE_ADDR"] && $login_inof[2]>time() ){
		//更新生命周期
		$up_sql = 'UPDATE viplist SET online="'.$login_inof[0].'|'.$login_inof[1].'|'.(time()+$out_login_time).'" WHERE vid="'.$_SESSION["vid"].'"';
		$conn->query($up_sql);
		return $vip_data;
	}
	
	//【OUT】 IP相同 && SSID不同  -->  本地    多浏览器登陆，多电脑登陆
	if( $_SERVER["REMOTE_ADDR"]==$login_inof[1] && $login_inof[0]!=session_id() ){
		session_unset();
		session_destroy();
		exit('loguot|<b class="logout">重复登陆</b>');
		
	//【OUT】 IP不同 && SSID不同  -->  多人使用
	}elseif( $_SERVER["REMOTE_ADDR"]!=$login_inof[1] &&  $login_inof[0]!=session_id() ){
		//log
		@$conn->query('INSERT INTO log(logtype, safety, info, ipaddress, logdate) VALUES ("usercheck","no","【共享账号】 vid='.$_SESSION["vid"].' , taoid='.$vip_data["taoid"].' 注册IP:'.$login_inof[1].' 注册时间:'.date("Y-m-d H:i:s",($login_inof[2]-$out_login_time)).'","'.$_SERVER["REMOTE_ADDR"].'","'.date("Y-m-d H:i:s").'")');
		session_unset();
		session_destroy();
		exit('loguot|<b class="logout">您的账号在其他地方登陆，<br>请不要把账号借给别人</b>');
		
	//【OUT】IP不同 && SSID相同   -->  断网换IP了 或者SSID泄露
	}elseif( $_SERVER["REMOTE_ADDR"]!=$login_inof[1] &&  $login_inof[0]==session_id() ){
		session_unset();
		session_destroy();
		exit('loguot|<b class="logout">请重新登陆</b>');
		
	//【OUT】 一段时间内没操作
	}elseif($login_inof[2]<time()){
		session_unset();
		session_destroy();
		exit('loguot|<b class="logout">您一段时间内没任何操作，请重新登陆！</b>');
	}else{
		session_unset();
		session_destroy();
	}
}



?>
