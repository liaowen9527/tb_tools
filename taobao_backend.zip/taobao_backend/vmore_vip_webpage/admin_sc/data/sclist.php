﻿<?php
require_once('../function/check.php');
require_once('../conf_ini.php');
	
//■■■■■■■■■■■■■■■■■■■■■■■■■■【素材查询】■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■

	//存在->分页参数 page limit
	if( @preg_match("/^[0-9]+$/",$_GET["page"]) && @preg_match("/^[0-9]+$/",$_GET["limit"]) ){
			
			//搜索ID
			if(!empty($_GET["searchkey"])){
				$searchkey = preg_split("/\s|,|，|\|/",$_GET["searchkey"]);
				foreach($searchkey as $val){
					if(@!empty($sql_where_key))  $sql_where_key.=',';
					@$sql_where_key.= '"'.$val.'"';
				}
				$sql_where_b = ' WHERE a.scid IN ('.$sql_where_key.') ';
				$sql_where = ' WHERE scid IN ('.$sql_where_key.') ';
			}else{
				$sql_where_b = '';
				$sql_where = '';
			}
		
			//排序
			if( @preg_match("/^[a-z_A-Z]+$/",$_GET["field"]) && @preg_match("/^ASC$|^DESC$|^asc$|^desc$/",$_GET["order"]) )
				if($_GET["field"]=='sidcount'){
					$order_by=' ORDER BY b.'.$_GET["field"].' '.$_GET["order"].' ';    //表B
				}else{
					$order_by=' ORDER BY a.'.$_GET["field"].' '.$_GET["order"].' ';    //表A
				}
			else
				$order_by='';
			
			//数量控制
			$sql_limit = 'SELECT a.sid,a.scid,a.title,a.down_add,a.add_time,a.slevel,a.display,b.sidcount FROM sclist a LEFT JOIN ( SELECT sid, COUNT(*) AS sidcount FROM loglist GROUP BY sid ) b ON a.sid = b.sid  '.$sql_where_b.$order_by.' LIMIT '.($_GET["page"]*$_GET["limit"]-$_GET["limit"]).','.$_GET["limit"].'';
			$sc_list = $conn->query($sql_limit);
	 // echo $sql_limit;
			//获取总数
			$sql_count = 'SELECT count(*) as count FROM sclist'.$sql_where;
			$sc_count = ($conn->query($sql_count))->fetch_assoc();
			$sc_count = $sc_count["count"];
		 
			//格式化数据
			if ($sc_list->num_rows > 0) {
				while($row = $sc_list->fetch_assoc()) {
					if(!empty($list)) $list.=',';
					if(empty($row["sidcount"])) $row["sidcount"]=0;
					@$list.='{"sid":"'.$row["sid"].'","scid":"'.$row["scid"].'","title":"'.$row["title"].'","down_add":"'.$row["down_add"].
							'","add_time":"'.$row["add_time"].'","sidcount":"'.$row["sidcount"].'","slevel":"'.$row["slevel"].'","display":"'.$row["display"].'"}';
				}
			}
			$list='{"code":0,"msg":"","count":'.$sc_count.',"data":['.@$list.']}';
			exit($list);
	}
	
//■■■■■■■■■■■■■■■■■■■■■■■■■■【更新 编辑】■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■

	//SVIP  VIP 素材调整
	if(@preg_match("/^[0-9]+$/",$_GET["slevelupid"]) && @preg_match("/^vip$|^svip$/",$_GET["slevelupdate"]) ){
			$sql_up_slevel = 'UPDATE sclist SET  slevel="'.$_GET["slevelupdate"].'" WHERE sid='.$_GET["slevelupid"];
			$conn->query($sql_up_slevel);
			exit;
	}
	 
	 
	//禁用素材调整
	if(@preg_match("/^[0-9]+$/",$_GET["displayupid"]) && @preg_match("/^disable$|^enable$/",$_GET["displayupdate"]) ){
			$sql_up_display = 'UPDATE sclist SET display="'.$_GET["displayupdate"].'" WHERE sid='.$_GET["displayupid"];
			$conn->query($sql_up_display);
			exit;
	}
 
    //更新内容
	if(@$_POST["mode"]=='updata' && @preg_match("/^[0-9]+$/",$_POST["sid"]) ){
			$_POST["scid"] = trim($_POST["scid"]);
			if(!@preg_match("/^\w+$/",$_POST["scid"]))	exit('<b style="font-size:25px;"><span style="color:#ff0000;">修改失败!</span><br>素材编号 必须为 字母或数字</b>');
			$_POST["title"] = trim(preg_replace("/\s+/",' ',$_POST["title"]));
			$_POST["down_add"] = trim(preg_replace("/\s+/",' ',$_POST["down_add"]));
			$sql_update = 'UPDATE sclist SET scid="'.$_POST["scid"].'", title="'.$_POST["title"].'", down_add="'.$_POST["down_add"].'" WHERE sid='.$_POST["sid"];
			if ( $conn->query($sql_update) === TRUE ) echo '修改成功';
			else echo '数据库错误！';
			exit;
	}
	//重新显示更新内容
	if(@$_GET["mode"]=='new_date' && @preg_match("/^[0-9]+$/",$_GET["sid"]) ){
		sleep(1);
		$sql_newdate='SELECT scid, title, down_add  FROM sclist WHERE sid='.$_GET["sid"];
		$newdate = $conn->query($sql_newdate);
		echo json_encode($newdate->fetch_assoc());
		exit;
	}
	
//■■■■■■■■■■■■■■■■■■■■■■■■■■【删除】■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■

    if(@preg_match("/^[0-9]+$/",$_GET["delid"]) ){
		$sql_delid = 'DELETE FROM sclist WHERE sid='.$_GET["delid"];
		$conn->query($sql_delid);
		exit;
	}

//■■■■■■■■■■■■■■■■■■■■■■■■■■【插入】■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■

    if(@$_POST["mode"]=='newdata' && @trim($_POST["new_data"]))  {
		//数据反馈
		$uplog=''; 
		//$var_list='';
		//按行分割
		$new_data = preg_split("/\r|\n/",$_POST["new_data"]);
		
		//遍历行 检查数据
		foreach($new_data as $var){
			//忽略空数据
			if(preg_match("/^\s+$/",$var) or empty($var)) continue;
			@$a++;

			//素材ID
			$var=preg_split("/\(|（/",$var);
			$var[0] = trim($var[0]);
			if(!preg_match("/^\w+$/",$var[0]))   exit('第 <b style="font-size:25px;color:#ffff00">'.$a.'</b> 行 ， <b style="color:#ff3355;font-size:20px;"> 素材ID </b>只能为字母数字</b>');
			else $var_list[$a]["scid"] = $var[0];
			
			//标题
			$var=@preg_split("/\)|）/",$var[1]);
			$var[0] = trim($var[0]);
			if(empty($var[0]))  exit('第 <b style="font-size:25px;color:#ffff00">'.$a.'</b> 行 ， <b style="color:#ff3355;font-size:20px;"> 标题 </b>读取错误，请检查格式</b>');
			else $var_list[$a]["title"] = @preg_replace("/\s+/",' ',$var[0]);   
			
			//下载地址
			$var[1] = @trim($var[1]);
			if(empty($var[1]))  exit('第 <b style="font-size:25px;color:#ffff00">'.$a.'</b> 行 ， <b style="color:#ff3355;font-size:20px;"> 下载地址 </b>读取错误，请检查格式</b>');
			else $var_list[$a]["down"] = @preg_replace("/\s+/",' ',$var[1]);   	
		}

		if($var_list){
			foreach($var_list as  $key=>$var){
				$sql = 'INSERT INTO sclist (scid,title,down_add,add_time) VALUES ("'.$var["scid"].'","'.$var["title"].'","'.$var["down"].'","'.date("Y-m-d").'")';
				if (($conn->query($sql) === TRUE))
					$uplog.='<b style="color:#00cc2d;"> 成功! </b><span style="color:#aaa;margin:0 5px 0 15px;">编号:</span>'.$var["scid"].'<span style="color:#aaa;margin:0 5px 0 15px;"> 标题:</span>'.$var["title"].'<span style="color:#aaa;margin:0 5px 0 15px;"> 下载:</span>'.$var["down"].'<br>';  //成功反馈
				else  
					$uplog.='<b style="color:#ff0000;"> 数据库错 </b><span style="color:#aaa;margin:0 5px 0 15px;">编号:</span>'.$var["scid"].'<span style="color:#aaa;margin:0 5px 0 15px;"> 标题:</span>'.$var["title"].'<span style="color:#aaa;margin:0 5px 0 15px;"> 下载:</span>'.$var["down"].'<br>';   //数据库错误反馈
			}
		}
		
		if($uplog=='') exit('无任何操作');
		else  exit ($uplog);
		
	}else if(@$_POST["mode"]=='newdata' && @empty(trim($_POST["new_data"])) ) {
		exit('请输入数据') ;
	} 

?>