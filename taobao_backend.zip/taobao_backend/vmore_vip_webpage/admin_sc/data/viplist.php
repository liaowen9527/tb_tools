﻿<?php 
require_once('../function/check.php');
require_once('../conf_ini.php');

//■■■■■■■■■■■■■■■■■■■■■■■■■■【VIP查询】■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
	//存在->分页参数 page limit
	if( @preg_match("/^[0-9]+$/",$_GET["page"]) && @preg_match("/^[0-9]+$/",$_GET["limit"]) ){
			
			//搜索ID
			if(!empty($_GET["searchkey"])){
				$searchkey = preg_split("/\s|,|，|\|/",$_GET["searchkey"]);
				foreach($searchkey as $val){
					if(@!empty($sql_where_key))  $sql_where_key.=',';
					@$sql_where_key.= '"'.$val.'"';
				}
				$sql_where_b = ' WHERE a.taoid IN ('.$sql_where_key.') ';
				$sql_where = ' WHERE taoid IN ('.$sql_where_key.') ';
			}else{
				$sql_where_b = '';
				$sql_where = '';
			}
		
			//排序
			if( @preg_match("/^[a-z_A-Z]+$/",$_GET["field"]) && @preg_match("/^ASC$|^DESC$|^asc$|^desc$/",$_GET["order"]) )
				if($_GET["field"]=='vidcount'){
					$order_by=' ORDER BY b.'.$_GET["field"].' '.$_GET["order"].' ';    //表B
				}else{
					$order_by=' ORDER BY a.'.$_GET["field"].' '.$_GET["order"].' ';    //表A
				}
				
			else
				$order_by='';
			
				
			
			//数量控制
			$sql_limit = 'SELECT a.vid,a.taoid,a.pass,a.qq,a.vx,a.rmbsum,a.u_add_time,a.vlevel,a.ban,b.vidcount FROM viplist a 
						LEFT JOIN (SELECT vid, COUNT(*) AS vidcount  FROM loglist  GROUP BY vid) b ON  a.vid=b.vid '.$sql_where_b.$order_by.' LIMIT '.($_GET["page"]*$_GET["limit"]-$_GET["limit"]).','.$_GET["limit"].'';
			$sc_list = $conn->query($sql_limit);
	 
	 //echo $sql_limit;
	 
			//获取总数
			$sql_count = 'SELECT count(*) as count FROM viplist'.$sql_where;
			$sc_count = ($conn->query($sql_count))->fetch_assoc();
			$sc_count = $sc_count["count"];
		 
			//格式化数据
			if ($sc_list->num_rows > 0) {
				while($row = $sc_list->fetch_assoc()) {
					if(!empty($list)) $list.=',';
					if(empty($row["vidcount"])) $row["vidcount"]=0;
					@$list.='{"vid":"'.$row["vid"].'","taoid":"'.$row["taoid"].'","pass":"'.$row["pass"].'","qq":"'.$row["qq"].'","vx":"'.$row["vx"].'","rmbsum":"'.$row["rmbsum"].'","u_add_time":"'.$row["u_add_time"].'","vidcount":"'.$row["vidcount"].'","vlevel":"'.$row["vlevel"].'","ban":"'.$row["ban"].'"}';
				}
			}
			$list='{"code":0,"msg":"","count":'.$sc_count.',"data":['.@$list.']}';
			exit($list);
	}
	
//■■■■■■■■■■■■■■■■■■■■■■■■■■【更新 编辑】■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■

	//SVIP  VIP 素材调整
	if(@preg_match("/^[0-9]+$/",$_GET["vlevelupid"]) && @preg_match("/^vip$|^svip$/",$_GET["vlevelupdate"]) ){
			$sql_up_vlevel = 'UPDATE viplist SET  vlevel="'.$_GET["vlevelupdate"].'" WHERE vid='.$_GET["vlevelupid"];
			$conn->query($sql_up_vlevel);
			exit;
	}
		//禁用素材调整
	if(@preg_match("/^[0-9]+$/",$_GET["banupid"]) && @preg_match("/^disable$|^enable$/",$_GET["banupdate"]) ){
			$sql_up_ban = 'UPDATE viplist SET ban="'.$_GET["banupdate"].'" WHERE vid='.$_GET["banupid"];
			$conn->query($sql_up_ban);
			exit;
	}
	    //更新内容
	if(@$_POST["mode"]=='updata' && @preg_match("/^[0-9]+$/",$_POST["vid"]) ){
		
			//淘宝ID [不能有空格]
			$_POST["taoid"]=trim($_POST["taoid"]);
			if(@preg_match("/\s+/",$_POST["taoid"]))	exit('<b style="font-size:25px;"><span style="color:#ff0000;">修改失败!</span><br>淘宝ID有空格</b>');
			//pass  [必须 数字或字母]
			$_POST["pass"]=trim($_POST["pass"]);
			if(!preg_match("/^[a-zA-Z0-9]+$/",$_POST["pass"]))   exit('<b style="font-size:25px;"><span style="color:#ff0000;">修改失败!</span><br>密码只能是字母数字</b>');
		    //qq [可以为空  但只能是数字]
			$_POST["qq"]=trim($_POST["qq"]);
			if($_POST["qq"] &&  !preg_match("/^[\d]+$/",$_POST["qq"]))   exit('<b style="font-size:25px;"><span style="color:#ff0000;">修改失败!</span><br>QQ格式错误</b>');
			//VX [不能有空格]
			$_POST["vx"]=trim($_POST["vx"]);
			if(@preg_match("/\s+/",$_POST["vx"]))	exit('<b style="font-size:25px;"><span style="color:#ff0000;">修改失败!</span><br>微信有空格</b>');
			//RMB [只能是数字]
			$_POST["rmbsum"]=trim($_POST["rmbsum"]);
			if(!preg_match("/^[1-9]+[0-9]*$|^[1-9]+[0-9]*.{1}[0-9]*[1-9]+$/",$_POST["rmbsum"]))	exit('<b style="font-size:25px;"><span style="color:#ff0000;">修改失败!</span><br>付款金额非数字</b>');
			
			$sql_update = 'UPDATE viplist SET taoid="'.$_POST["taoid"].'", pass="'.$_POST["pass"].'", qq="'.$_POST["qq"].'" , vx="'.$_POST["vx"].'" , rmbsum="'.$_POST["rmbsum"].'" WHERE vid='.$_POST["vid"];
			if ( $conn->query($sql_update) === TRUE ) echo '修改成功';
			else echo '数据库错误！';
			exit;
	}

	//重新显示更新内容
	if(@$_GET["mode"]=='new_date' && @preg_match("/^[0-9]+$/",$_GET["vid"]) ){
		sleep(1);
		$sql_newdate='SELECT taoid, pass, qq, vx, rmbsum  FROM viplist WHERE vid='.$_GET["vid"];
		$newdate = $conn->query($sql_newdate);
		echo json_encode($newdate->fetch_assoc());
		exit;
	}
//■■■■■■■■■■■■■■■■■■■■■■■■■■【删除】■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■

    if(@preg_match("/^[0-9]+$/",$_GET["delvid"]) ){
		$sql_delid = 'DELETE FROM viplist WHERE vid='.$_GET["delvid"];
		$conn->query($sql_delid);
		exit;
	}
	
//■■■■■■■■■■■■■■■■■■■■■■■■■■【插入】■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■

    if(@$_POST["mode"]=='newVIP'){
		
		//淘宝ID [不能有空格]
		$_POST["taoid"]=trim($_POST["taoid"]);
		if(@preg_match("/\s+/",$_POST["taoid"]))	exit('<b style="font-size:25px;"><span style="color:#ff0000;">修改失败!</span><br>淘宝ID有空格</b>');
		//pass  [必须 数字或字母]
		$_POST["pass"]=trim($_POST["pass"]);
		if(!preg_match("/^[a-zA-Z0-9]+$/",$_POST["pass"]))   exit('<b style="font-size:25px;"><span style="color:#ff0000;">修改失败!</span><br>密码只能是字母数字</b>');
	    //qq [可以为空  但只能是数字]
		$_POST["qq"]=trim($_POST["qq"]);
		if($_POST["qq"] &&  !preg_match("/^[\d]+$/",$_POST["qq"]))   exit('<b style="font-size:25px;"><span style="color:#ff0000;">修改失败!</span><br>QQ格式错误</b>');
		//VX [不能有空格]
		$_POST["vx"]=trim($_POST["vx"]);
		if(@preg_match("/\s+/",$_POST["vx"]))	exit('<b style="font-size:25px;"><span style="color:#ff0000;">修改失败!</span><br>微信有空格</b>');
		//RMB [只能是数字]
		$_POST["rmbsum"]=trim($_POST["rmbsum"]);
		if(!preg_match("/^[1-9]+[0-9]*$|^[1-9]+[0-9]*.{1}[0-9]*[1-9]+$/",$_POST["rmbsum"]))	exit('<b style="font-size:25px;"><span style="color:#ff0000;">修改失败!</span><br>付款金额非数字</b>');
		

		$sql = 'INSERT INTO viplist (taoid,pass,qq,vx,rmbsum,u_add_time) VALUES ("'.$_POST["taoid"].'","'.$_POST["pass"].'","'.$_POST["qq"].'","'.$_POST["vx"].'","'.$_POST["rmbsum"].'","'.date("Y-m-d").'")';
		if (($conn->query($sql) === TRUE))
			$uplog='<b style="color:#00cc2d;margin:0 5px 0 15px;"> 添加成功！ </b><br><span style="color:#aaa;margin:0 5px 0 15px;">淘宝ID: </span>'.$_POST["taoid"].'<br><span style="color:#aaa;margin:0 5px 0 15px;">密码: </span>'.$_POST["pass"].'<br><span style="color:#aaa;margin:0 5px 0 15px;">QQ: </span>'.$_POST["qq"].'<br><span style="color:#aaa;margin:0 5px 0 15px;">微信: </span>'.$_POST["vx"].'<br><span style="color:#aaa;margin:0 5px 0 15px;">购买金额: </span>'.$_POST["rmbsum"];  //成功反馈
		else  
			$uplog='<b style="color:#ffcb06;"> 数据库错 </b>';  //数据库错误反馈
		echo $uplog;
		exit;
		
	}

		
//■■■■■■■■■■■■■■■■■■■■■■■■■■【批量插入】■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■

    if(@$_POST["mode"]=='newVIPs' && trim($_POST["newVipDatas"])){
 		//数据反馈
		$uplog=''; 
		$var_list='';
		//按行分割
		$new_data = preg_split("/\r|\n/",$_POST["newVipDatas"]); 
		
		//遍历行 检查数据
		foreach($new_data as $var){
			//忽略空数据
			if(preg_match("/^\s+$/",$var) or empty($var)) continue;
			@$a++;
			//获取原始记录
			$var_log[$a] = $var;
			
			//逗号分割
			$var = preg_split("/,|，/",$var);
				
			//检查多余数据
			if(empty($var[4]) or !empty($var[5]))	exit('第 <b style="font-size:25px;color:#ffff00">'.$a.'</b> 行 ， <b style="color:#ff3355;font-size:20px;"> 缺少 </b> 或 <b style="color:#ff3355;font-size:20px;">多余</b> 数据</b><br>数据之间用逗号隔开，回车换行');
				
			//taoid  [不能有空格]
			$var[0] = trim($var[0]);
			if(preg_match("/\s+/",$var[0])) exit('第 <b style="font-size:25px;color:#ffff00">'.$a.'</b> 行 ， <b style="color:#ff3355;font-size:20px;"> 淘宝ID </b>有空格</b>');
			else  $var_list[$a]["taoid"]=$var[0];
				
			//pass  [必须 数字或字母]
			$var[1] = trim($var[1]);
			if(!preg_match("/^[a-zA-Z0-9]+$/",$var[1]))	exit('第 <b style="font-size:25px;color:#ffff00">'.$a.'</b> 行 ， <b style="color:#ff3355;font-size:20px;"> 密码 </b>只能数字或字母</b>');
			else  $var_list[$a]["pass"]=$var[1];
				
			//qq [可以为空  但只能是数字]
			$var[2] = trim($var[2]);
			if($var[2] &&  !preg_match("/^[\d]+$/",$var[2]))   exit('第 <b style="font-size:25px;color:#ffff00">'.$a.'</b> 行 ， <b style="color:#ff3355;font-size:20px;"> QQ </b>只能是数字</b>');
			else  $var_list[$a]["qq"]=$var[2];
				
			//vx [不能有空格]
			$var[3] = trim($var[3]);
			if(@preg_match("/\s+/",$var[3]))	  exit('第 <b style="font-size:25px;color:#ffff00">'.$a.'</b> 行 ， <b style="color:#ff3355;font-size:20px;"> 微信 </b>包含空格</b>');
			else  $var_list[$a]["vx"]=$var[3];
				
			//RMB [只能是数字]
			$var[4] = trim($var[4]);
			if(!preg_match("/^[1-9]+[0-9]*$|^[1-9]+[0-9]*.{1}[0-9]*[1-9]+$/",$var[4]))	  exit('第 <b style="font-size:25px;color:#ffff00">'.$a.'</b> 行 ， <b style="color:#ff3355;font-size:20px;"> 付款金额 </b>非纯数字</b>');
			else  $var_list[$a]["rmbsum"]=$var[4];
		}
		
		//写入数据
		if($var_list)
		foreach($var_list as $var){
			$sql = 'INSERT INTO viplist (taoid,pass,qq,vx,rmbsum,u_add_time) VALUES ("'.$var["taoid"].'","'.$var["pass"].'","'.$var["qq"].'","'.$var["vx"].'","'.$var["rmbsum"].'","'.date("Y-m-d").'")';
			if (($conn->query($sql) === TRUE))
				$uplog.='<b style="color:#00cc2d;"> 成功! </b><span style="color:#aaa;margin:0 5px 0 15px;">淘宝ID:</span>'.$var["taoid"].'<span style="color:#aaa;margin:0 5px 0 15px;"> 密码:</span>'.$var["pass"].'<span style="color:#aaa;margin:0 5px 0 15px;"> QQ:</span>'.$var["qq"].'<span style="color:#aaa;margin:0 5px 0 15px;"> 微信:</span>'.$var["vx"].'<span style="color:#aaa;margin:0 5px 0 15px;"> 购买金额:</span>'.$var["rmbsum"].'<br>';  //成功反馈
			else  
				$uplog.='<b style="color:#ff0000;"> 数据库错误! </b><span style="color:#aaa;margin:0 5px 0 15px;">淘宝ID:</span>'.$var["taoid"].'<span style="color:#aaa;margin:0 5px 0 15px;"> 密码:</span>'.$var["pass"].'<span style="color:#aaa;margin:0 5px 0 15px;"> QQ:</span>'.$var["qq"].'<span style="color:#aaa;margin:0 5px 0 15px;"> 微信:</span>'.$var["vx"].'<span style="color:#aaa;margin:0 5px 0 15px;"> 购买金额:</span>'.$var["rmbsum"].'<br>';  //成功失败
		}
		echo $uplog;	
} 
?>