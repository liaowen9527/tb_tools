﻿<?php  
require_once('../function/check.php');
require_once('../conf_ini.php');

//■■■■■■■■■■■■■■■■■■■■■■■■■■【素材记录查询】■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
	//存在->分页参数 page limit
	if( @preg_match("/^[0-9]+$/",$_GET["page"]) && @preg_match("/^[0-9]+$/",$_GET["limit"]) ){
			
			//搜索ID
			if(!empty($_GET["searchkey"])){
				$searchkey = preg_split("/\s+|,/",$_GET["searchkey"]);
				foreach($searchkey as $val){
					if(empty($val)) continue;
					if(!empty($sql_where_key))  $sql_where_key.=',';
					@$sql_where_key.= '"'.$val.'"';
				}
 
				if($_GET["mode"]=='user'){
					$sql_where_b = ' WHERE c.taoid IN ('.$sql_where_key.') ';
					
				}elseif($_GET["mode"]=='sc'){
					$sql_where_b = ' WHERE d.scid IN ('.$sql_where_key.') ';
				}
				
			}else{
					$sql_where_b = '';
			}
			//时间范围
			if(!empty($_GET["date"]) && preg_match("/^\d{4}-\d{1,2}-\d{1,2}\s+-\s+\d{4}-\d{1,2}-\d{1,2}$/",$_GET["date"])){
				
				$_GET["date"] = preg_split("/\s+-\s+/",$_GET["date"]); //分割时间
				$sql_where = ' WHERE logtime between  "'.$_GET["date"][0].'" and "'.$_GET["date"][1].'"';
				if($sql_where_b!='')   
					$sql_where_b.=' AND a.logtime between  "'.$_GET["date"][0].'" and "'.$_GET["date"][1].'"';
				else 
					$sql_where_b =  ' WHERE a.logtime between  "'.$_GET["date"][0].'" and "'.$_GET["date"][1].'"';
				
			}else{
				$sql_where='';
			}
	
			//排序

			
			if( @preg_match("/^[a-z_A-Z]+$/",$_GET["field"]) && @preg_match("/^ASC$|^DESC$|^asc$|^desc$/",$_GET["order"]) ){
				if(@$_GET["field"]=='logid' or @$_GET["field"]=='logtime') $_GET["field"]='a.'.$_GET["field"];   //根据排序字段 增加别名
				$order_by=' ORDER BY '.$_GET["field"].' '.$_GET["order"].' ';
			}else
				$order_by='';
            
			$sql_limit='SELECT  a.logid, a.vid, c.taoid, d.scid, d.title, a.logtime, b.vidcount, e.vidcount_all
			FROM   loglist a
			LEFT JOIN (SELECT vid, COUNT(*) AS vidcount  FROM loglist '.$sql_where.' GROUP BY vid) b ON  a.vid=b.vid
			LEFT JOIN (SELECT vid, COUNT(*) AS vidcount_all  FROM loglist  GROUP BY vid) e ON  a.vid=e.vid
			LEFT JOIN viplist c ON  a.vid=c.vid  
			LEFT JOIN sclist d  ON  a.sid=d.sid '.
			$sql_where_b.$order_by.' LIMIT '.($_GET["page"]*$_GET["limit"]-$_GET["limit"]).','.$_GET["limit"].'';
			
		// echo $sql_limit;  
			
			$sc_list = $conn->query($sql_limit);

			$sql_count='SELECT count(*) as count
						FROM   loglist a
						LEFT JOIN (SELECT vid, COUNT(*) AS vidcount  FROM loglist '.$sql_where.' GROUP BY vid) b ON  a.vid=b.vid
						LEFT JOIN viplist c ON  a.vid=c.vid  
						LEFT JOIN sclist d  ON  a.sid=d.sid '.
						$sql_where_b;
			
			$sc_count = ($conn->query($sql_count))->fetch_assoc();
			$sc_count = $sc_count["count"];
			//格式化数据
			if ($sc_list->num_rows > 0) {
				while($row = $sc_list->fetch_assoc()) {
					if(!empty($list)) $list.=',';
					@$list.='{"vid":"'.$row["vid"].'","logid":"'.$row["logid"].'","taoid":"'.$row["taoid"].'","scid":"'.$row["scid"].'","title":"'.$row["title"].'","logtime":"'.$row["logtime"].'","vidcount":"'.$row["vidcount"].'","vidcount_all":"'.$row["vidcount_all"].'"}';
				}
			}
			$list='{"code":0,"msg":"","count":'.$sc_count.',"data":['.@$list.']}';
			exit($list);
	}

?>