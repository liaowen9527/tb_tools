﻿<?php 
require_once('function/check.php'); 

echo <<<EOF
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>素材管理</title>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport">
  <link rel="stylesheet" href="../layui/css/layui.css"  media="all">
</head>
<body>
<div class="demoTable" style="margin:15px">
  搜索编号：
  <div class="layui-inline">
    <input class="layui-input" name="id" id="demoReload" style="width:400px;" autocomplete="off">
  </div>
  <button style="margin:0 0 0 10px;" class="layui-btn" data-type="reload" >搜索</button>
  <button class="layui-btn addSc layui-btn-danger" lay-submit >批量添加素材</button>
</div>

<table class="layui-table" lay-data="{width: 1415, height:783, url:'data/sclist.php', page:true, id:'idTest', limit:18}" lay-filter="demo">
  <thead>
    <tr>
	 <th lay-data="{field:'sid', width:55, sort: true}">ID</th>
      <th lay-data="{field:'scid', width:100, sort: true}">素材编号</th>
      <th lay-data="{field:'title', templet: '#newSc',width:300}">素材名</th>
      <th lay-data="{field:'down_add', width:400}">下载地址</th>
	  <th lay-data="{field:'sidcount', width:100, sort: true}">取货 / 次</th>
      <th lay-data="{field:'add_time', width:110, sort: true}">添加时间</th>
	  <th lay-data="{field:'slevel', width:90, templet: '#switchTpl', unresize: true,sort: true}">权限</th>
	  <th lay-data="{field:'display', width:120, templet: '#checkboxTpl', unresize: true,sort: true}">禁用</th>
      <th lay-data="{fixed: 'right', width:130, align:'center', toolbar: '#barDemo'}">编辑/删除</th>
    </tr>
  </thead>
</table>
<script type="text/html" id="newSc">
  <!-- VIP新加入  -->
   {{# var  sysDate = new Date().getTime(); }}
   {{# var  newDate = new Date(d.add_time).getTime(); }}
   {{# if(((sysDate-newDate)/3600000)<24){ }}
   {{d.title}}<span style="position: absolute; top: 1px; right: 5px; background: #6eb500; color: #fff; border-radius: 15px; font-size: 10px; height: 10px; width: 10px; line-height: 10px; opacity: 0.8;"></span>
   {{#  } else { }}
   {{d.title}}
   {{#  } }}
</script>
<script type="text/html" id="barDemo">
  <!-- bardemo工具条 -->
  <a class="layui-btn layui-btn-xs" name={{d.sid+'|'+d.scid}} lay-event="edit">编辑</a>
  <a class="layui-btn layui-btn-danger layui-btn-xs" name={{d.sid+'|'+d.scid}}  lay-event="del">删除</a>
</script>
<script type="text/html" id="switchTpl">
  <!--  checked  -->
  <input type="checkbox" name="{{d.sid+'|'+d.scid}}" value="{{d.slevel}}" lay-skin="switch" lay-text="svip|vip" lay-filter="slevel" {{ d.slevel == 'svip' ? 'checked' : '' }}>
</script>
<script type="text/html" id="checkboxTpl">
  <!--  checked  -->
  <input type="checkbox" name="{{d.sid+'|'+d.scid}}" value="{{d.display}}" title="禁用" lay-filter="display" {{ d.display == 'disable' ? 'checked' : '' }}>
</script>
			   
          
<script src="../layui/layui.js" charset="utf-8"></script>
<script src="../layui/lay/modules/jquery.min.js" charset="utf-8"></script>
<script>

layui.use('table', function(){
  var table = layui.table, 
  form = layui.form;
 
//■■■■■■■■■■■■■■■ 监听工具条 ■■■■■■■■■■■■■■■■■■
  table.on('tool(demo)', function(obj){
	  
    var data = obj.data,
		nameid = this.name;
		
    if(obj.event === 'del'){
        layer.confirm('确定删除 < '+nameid.split("|")[1]+' > 吗？',{icon:2,title:'<b style="font-size:20px;">删除确认！</b>'} ,function(index){
		layer.msg( nameid.split("|")[1]+' &nbsp; 删除成功！');
		$.get("data/sclist.php", {delid:nameid.split("|")[0]});
        obj.del();
        layer.close(index);
      });
	
    } else if(obj.event === 'edit'){
		//设置表单内容
		 $("#scid").val(data.scid);
		 $("#title").val(data.title);
		 $("#down_add").val(data.down_add);

		//打开表单
		var scEditorHtml = layer.open({
		  type: 1,
		  title: '<b style="font-size:20px;">编辑 <b> ( '+data.sid+' ) '+data.scid,
		  closeBtn: 1, //显示关闭按钮
		  shade: [0.3],
		  area: ['600px', '280px'],
		  offset: 'auto',  
		  content: $('#scEditor') //iframe的url，no代表不显示滚动条
		});
		
		//监听提交按钮
		form.on('submit(formDemo)', function(){
		  //提交表单
		  $.post("data/sclist.php",{
			  mode:'updata',
			  sid: data.sid,
			  scid: $("#scid").val(),
			  title: $("#title").val(),
			  down_add: $("#down_add").val()
			}, function(data5){
				if(data5=='修改成功'){
					//关闭页面 反馈成功
					layer.close(scEditorHtml);
					layer.msg(data5)
					
				  //查询更新的内容
				  $.get("data/sclist.php", {
					  mode: 'new_date',
					  sid: data.sid
					}, function(data6){
						var newdate=JSON.parse(data6);
						//更新表格内容
						obj.update({
						  scid: newdate.scid
						  ,title: newdate.title
						  ,down_add: newdate.down_add
						});
					});
					
				}else{
					layer.msg(data5);
				}
			});
			
			return false;
	
		});
    }
  });

//■■■■■■■■■■■ 搜索内容 ■■■■■■■■■■■■
  var $ = layui.$, active = {
    reload: function(){
      var demoReload = $('#demoReload');
      
      //执行重载
      table.reload('idTest', {
        page: {
          curr: 1 //重新从第 1 页开始
        },where: {
          searchkey: demoReload.val()
        }
      });
    }
  };
  
  $('.demoTable .layui-btn').on('click', function(){
    var type = $(this).data('type');
    active[type] ? active[type].call(this) : '';
  });
  
//■■■■■■■■■■■■ 排序排序排序 重新请求服务器 加载 ■■■■■■■■■■■■■■■
  table.on('sort(demo)', function(obj){ //注：tool是工具条事件名，test是table原始容器的属性 lay-filter="对应的值"
  table.reload('idTest', {  //table.reload 重新请求服务器
    initSort: obj //记录初始排序，如果不设的话，将无法标记表头的排序状态。 layui 2.1.1 新增参数
    ,where: { //请求参数（注意：这里面的参数可任意定义，并非下面固定的格式）
      field: obj.field //排序字段
      ,order: obj.type //排序方式
    }
  });
});
 	
//■■■■■■■■■■■■ 监听SVIP / VIP 操作 ■■■■■■■■■■■■
  form.on('switch(slevel)', function(obj){
    layer.tips(this.name.split("|")[1] + '  -  '+ (obj.elem.checked == true ? 'SVIP 专用' : '普通素材'), obj.othis);
	$.get("data/sclist.php", { slevelupid:this.name.split("|")[0], slevelupdate:obj.elem.checked == true ? 'svip' : 'vip'});
  });
  
//■■■■■■■■■■■■ 监听锁定操作 ■■■■■■■■■■■■■■■
  form.on('checkbox(display)', function(obj){
    layer.tips(this.name.split("|")[1] + '  -  '+ (obj.elem.checked == true ? '禁止取货' : '解除限制'), obj.othis);
	$.get("data/sclist.php", { displayupid:this.name.split("|")[0], displayupdate:obj.elem.checked == true ? 'disable' : 'enable'});
  });
//■■■■■■■■■■■■■ 批量添加素材 ■■■■■■■■■■■■■
	//监听编辑添加内容按钮
	$('.demoTable .addSc').on('click', function(){
		//打开表单
		var index2 = layer.open({
		  type: 1,
		  title: '<b style="font-size:20px;">批量添加素材 <b>',
		  closeBtn: 1, 
		  shade: [0.3],
		  area: ['1200px', '340px'],
		  offset: 'auto',  
		  content: $('#add_sclist') 
		});
		
		//点击【提交】按钮
		form.on('submit(getScData)', function(){
		  //提交表单
		  $.post("data/sclist.php",{
			  mode:'newdata',
			  new_data: $("#addNewData").val()
			}, function(data4){
				if(data4.search('成功')!=-1){	
					//反馈成功 窗口
					layer.alert(data4, {
					  area: '1000px'
					 ,skin: 'layui-layer-molv' //样式类名
					 ,closeBtn: 0
					});
					
					//清空表单 关闭窗口
					$("#addNewData").val("");  //清空表单
					layer.close(index2);
					
					//延迟1秒 执行重载
					setTimeout(function(){
						table.reload('idTest', {
							page: {
							  curr: 1 //重新从第 1 页开始
							},
							where: {
							  field: 'sid' //排序字段
							  ,order: 'desc' //排序方式
							}
						  });
					},1000);
					
				}else{
					layer.msg(data4);	
				}
			});
			
			return false;
		})
		  
	});

});
</script>
</body>
<!---编辑内容html模板 --->
<div style="display:none;margin:20px 50px 20px 20px" id="scEditor" > 
 <form class="layui-form" action="" method="post">
  <div class="layui-form-item">
    <label class="layui-form-label" style="fontsize:15px;">素材编号</label>
    <div class="layui-input-block">
      <input type="text" id="scid" name="scid" required  lay-verify="required"  placeholder="请输入标题" autocomplete="off" class="layui-input">
    </div>
  </div>
  <div class="layui-form-item">
    <label class="layui-form-label">素材名</label>
    <div class="layui-input-block">
      <input type="text" id="title" name="title" required  lay-verify="required"  placeholder="请输入标题" autocomplete="off" class="layui-input">
    </div>
  </div>
    <div class="layui-form-item">
    <label class="layui-form-label">下载地址</label>
    <div class="layui-input-block">
      <input type="text" id="down_add" name="down_add" required  lay-verify="required"  placeholder="请输入标题" autocomplete="off" class="layui-input">
    </div>
  </div>
  <div class="layui-form-item">
    <div class="layui-input-block">
      <button class="layui-btn" lay-submit  lay-filter="formDemo">立即提交</button>
      <button type="reset" class="layui-btn layui-btn-primary">重置</button>
    </div>
  </div>
</form>
</div>
<div style="display:none;margin:30px 30px 0;" id="add_sclist" >
 <form class="layui-form" action="" method="post">
<textarea name="desc" id="addNewData" style="height:180px;" placeholder="P001（素材名）链接:https://pan.baidu.com/11111 密码xxxx  <回车换行>" class="layui-textarea"></textarea>
	<div style="margin:20px;text-align: center;">
		<button class="layui-btn" lay-submit  lay-filter="getScData">立即提交</button>
		<button type="reset" class="layui-btn layui-btn-primary">重置</button>
	</div>
 </form>
</div>
</html>       
EOF;
?>