<?php 
session_start();

//认证身份
if( empty($_SESSION["admin_hzh"]) OR $_SESSION["ip_add"]!=$_SERVER["REMOTE_ADDR"] ){
	session_unset();
	session_destroy();
	exit();
}


?>