<?php 
session_start();
require_once('../conf_ini.php');


//后台登陆的密码  你自己通过这个函数  运行生成密码  替换掉变量 $SC_PASS 的值
function passCryt($pass){
	$pass=strrev(md5($pass));
	$pass='Az975snXMsz1sGx1Gsqhpo7Pnslsq9Gvdf67QRxvaLnwit'.$pass;
	$pass=strrev(md5($pass));
	$pass=crypt($pass,'s4d55g4fgdfe17JQtuoiNmx1xqV1');
	return $pass;
}
$SC_USER='328976809@qq.com';
$SC_PASS='s4qSUF7ID8Oos';

//过滤函数
function safe_replace($string) {
    $string = str_replace('%20','',$string);
    $string = str_replace('%27','',$string);
    $string = str_replace('%2527','',$string);
    $string = str_replace('*','',$string);
    $string = str_replace('"','&quot;',$string);
    $string = str_replace("'",'',$string);
    $string = str_replace('"','',$string);
    $string = str_replace(';','',$string);
    $string = str_replace('<','&lt;',$string);
    $string = str_replace('>','&gt;',$string);
    $string = str_replace("{",'',$string);
    $string = str_replace('}','',$string);
    $string = str_replace('\\','',$string);
    return $string;
}

//■■■■■■■■■■■■■■■■■■■ 登陆 ■■■■■■■■■■■■■■■■■■■
if(empty($_SESSION["admin_hzh"]) && @$_POST["username"] && @$_POST["password"] && @$_POST["vercode"]){
		//yzm错误
		if( strcasecmp($_POST["vercode"],$_SESSION["captcha_sc"])!=0 ) exit('error');
		
		//包含恶意字符
		$username = safe_replace($_POST["username"]);
		$password = safe_replace($_POST["password"]);
		if($username!=$_POST["username"] OR $password!=$_POST["password"]){
			@$conn->query('INSERT INTO log(logtype, safety, info, ipaddress, logdate) VALUES ("admin","yes","【管理员登陆】登陆时检测到恶意代码！过滤之后的用户名：'.$username.' , 密码：'.$password.'","'.$_SERVER["REMOTE_ADDR"].'","'.date("Y-m-d H:i:s").'")');
			exit('error');
		}
		
		//认证登陆
	 if($_POST["username"]==$SC_USER && passCryt($_POST["password"])==$SC_PASS ){
		$_SESSION["admin_hzh"]=$_POST["username"];   //认证
		$_SESSION["ip_add"]=$_SERVER["REMOTE_ADDR"]; //认证
		//log
		@$conn->query('INSERT INTO log(logtype, safety, info, ipaddress, logdate) VALUES ("admin","no","【管理员登陆】管理员登陆成功！","'.$_SERVER["REMOTE_ADDR"].'","'.date("Y-m-d H:i:s").'")');
		exit('dlcg');
	 }else{
		//log
		@$conn->query('INSERT INTO log(logtype, safety, info, ipaddress, logdate) VALUES ("admin","yes","【管理员登陆】管理员登陆【失败】！用户名：'.$username.' , 密码：'.$password.'","'.$_SERVER["REMOTE_ADDR"].'","'.date("Y-m-d H:i:s").'")');
		exit('error');
	 }
	 
}

//■■■■■■■■■■■■■■■■■■■■■ 退出 ■■■■■■■■■■■■■■■■■■■
if(!empty($_SESSION["admin_hzh"]) && @$_GET["mode"]=='logout'){
	session_unset();
	session_destroy();
	exit();
}

//■■■■■■■■■■■■■■■■■■■■■■■■■■■ 验证码AJAX ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
if( empty($_SESSION["admin_hzh"]) && isset($_GET["yzm_code"]) && !empty($_GET["yzm_code"]) ){
	//验证码对比
	if( strcasecmp($_GET["yzm_code"],$_SESSION["captcha_sc"])==0 ){
		exit("1");
	}else{
		exit("0");
	}
}

?>

