﻿<?php 
require_once('function/check.php'); 

echo <<<EOF
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>VIP管理</title>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport">
  <link rel="stylesheet" href="../layui/css/layui.css"  media="all">
</head>
<body>
<div class="demoTable" style="margin:15px">
  搜索会员：
  <div class="layui-inline">
    <input class="layui-input" name="id" id="demoReload" style="width:400px;" autocomplete="off">
  </div>
  <button class="layui-btn" data-type="reload" >搜索</button>
  <button class="layui-btn addVip layui-btn-danger" lay-submit >添加新会员</button>
  <button class="layui-btn addVips layui-btn-danger" lay-submit >批量</button>
</div>

<table class="layui-table" lay-data="{width: 1347, height:783, url:'data/viplist.php', page:true, id:'idTest', limit:18}" lay-filter="demo">
  <thead>
    <tr>
	 <th lay-data="{field:'vid', width:55,sort: true}">ID</th>
      <th lay-data="{field:'taoid',templet: '#newVip', width:180}">淘宝ID</th>
      <th lay-data="{field:'pass', width:150}">取货密码</th>
      <th lay-data="{field:'qq', templet: '#qqHtml',width:150}">QQ</th>
	  <th lay-data="{field:'vx', templet: '#vxHtml',width:150}">微信</th>
	  <th lay-data="{field:'rmbsum',templet: '#rmbSum', width:100}">付款金额</th>	  
      <th lay-data="{field:'u_add_time', width:110, sort: true}">添加时间</th>
	  <th lay-data="{field:'vidcount', width:100, sort: true}">取货/次</th>
	  <th lay-data="{field:'vlevel', width:90, templet: '#switchTpl', unresize: true,sort: true}">等级</th>
	  <th lay-data="{field:'ban', width:120, templet: '#checkboxTpl', unresize: true,sort: true}">停用</th>
      <th lay-data="{fixed: 'right', width:130, align:'center', toolbar: '#barDemo'}">编辑/删除</th>
    </tr>
  </thead>
</table>
<script type="text/html" id="rmbSum">
  <!-- qq  -->
   {{# var rmb_data = d.rmbsum.split("."); }}
   {{# var rmb_html = '<b style="font-size:18px">'+rmb_data[0]+'</b>'; }}
   {{# if(rmb_data[1]!=null){ }}
   {{#    rmb_html += '<b style="font-size:13px">.'+rmb_data[1]+'</b>'; }}
   {{#  } }}
   {{rmb_html}}<span style="color: #b7b7b7; padding: 1px 5px; font-size: 10px; border-radius: 8px;">RMB</span>
</script>
<script type="text/html" id="newVip">
  <!-- VIP新加入  -->
   {{# var  sysDate = new Date().getTime();}}
   {{# var  newDate = new Date(d.u_add_time).getTime();}}
   {{#  if(((sysDate-newDate)/3600000)<24){ }}
   {{d.taoid}}<span style="position: absolute; top: 1px; right: 5px; background: #6eb500; color: #fff; border-radius: 15px; font-size: 10px; height: 10px; width: 10px; line-height: 10px; opacity: 0.8;"></span>
   {{#  } else { }}
   {{d.taoid}}
   {{#  } }}
</script>
<script type="text/html" id="qqHtml">
  <!-- qq  -->
   {{#  if(d.qq != ''){ }}
   <span style="font-size: 10px; background: #45b4ea; color: #fff; padding: 2px 5px 1px; margin-right: 5px; border-radius: 85px;">Q</span>{{d.qq}}
  {{#  } }}
</script>
<script type="text/html" id="vxHtml">
  <!-- qq  -->
   {{#  if(d.vx != ''){ }}
   <span style="font-size: 10px; background: #92d64a; color: #fff; padding: 2px 5px 1px; margin-right: 5px; border-radius: 85px;">V</span>{{d.vx}}
  {{#  } }}
</script>
<script type="text/html" id="barDemo">
  <!-- bardemo工具条 -->
  <a class="layui-btn layui-btn-xs" name={{d.sid+'|'+d.scid}} lay-event="edit">编辑</a>
  <a class="layui-btn layui-btn-danger layui-btn-xs" name={{d.vid+'|'+d.taoid}}  lay-event="del">删除</a>
</script>
<script type="text/html" id="switchTpl">
  <!--  checked  -->
  <input type="checkbox" name="{{d.vid+'|'+d.taoid}}" value="{{d.vlevel}}" lay-skin="switch" lay-text="svip|vip" lay-filter="vlevel" {{ d.vlevel == 'svip' ? 'checked' : '' }}>
</script>
<script type="text/html" id="checkboxTpl">
  <!--  checked  -->
  <input type="checkbox" name="{{d.vid+'|'+d.taoid}}" value="{{d.ban}}" title="禁用" lay-filter="ban" {{ d.ban == 'disable' ? 'checked' : '' }}>
</script>
			   
          
<script src="../layui/layui.js" charset="utf-8"></script>
<script src="../layui/lay/modules/jquery.min.js" charset="utf-8"></script>
<script>

layui.use('table', function(){
  var table = layui.table, 
  form = layui.form;
  
//■■■■■■■■■■■■■■■ 监听工具条 ■■■■■■■■■■■■■■■■■■
  table.on('tool(demo)', function(obj){
	  
    var data = obj.data,
		nameid = this.name;
		
    if(obj.event === 'del'){
        layer.confirm('确定删除 < '+nameid.split("|")[1]+' > 吗？',{icon:2,title:'<b style="font-size:20px;">删除确认！</b>'} ,function(index){
		layer.msg( nameid.split("|")[1]+' &nbsp; 删除成功！');
		$.get("data/viplist.php", {delvid:nameid.split("|")[0]});
        obj.del();
        layer.close(index);
      });
	
    } else if(obj.event === 'edit'){
		//设置表单内容
		 $("#taoid").val(data.taoid);
		 $("#pass").val(data.pass);
		 $("#qq").val(data.qq);
		 $("#vx").val(data.vx);
		 $("#rmbsum").val(data.rmbsum);

		//打开表单
		var open_edit=layer.open({
		  type: 1,
		  title: '<b style="font-size:20px;">编辑会员'+data.vid+'  <span style="color:#009688">'+data.taoid+'</span></b>',
		  closeBtn: 1, //显示关闭按钮
		  shade: [0.3],
		  area: ['400px', '420px'],
		  offset: 'auto',  
		  content: $('#scEditor') //iframe的url，no代表不显示滚动条
		});
		
		//监听提交按钮
		form.on('submit(formDemo)', function(){
		  //提交表单
		  $.post("data/viplist.php",{
			  mode:'updata',
			  vid: data.vid,
			  taoid: $("#taoid").val(),
			  pass: $("#pass").val(),
			  qq: $("#qq").val(),
			  vx: $("#vx").val(),
			  rmbsum: $("#rmbsum").val()
			}, function(http_data){
				if(http_data=='修改成功'){
					//关闭页面 反馈成功消息
					layer.close(open_edit);
					layer.msg(http_data);
					
					 //查询更新的内容
					 $.get("data/viplist.php", {
						  mode: 'new_date',
						  vid: data.vid
					}, function(http_data2){
							var newdate=JSON.parse(http_data2);
							//更新表格内容
							obj.update({
							  taoid: newdate.taoid
							  ,pass: newdate.pass
							  ,qq: newdate.qq
							  ,vx: newdate.vx
							  ,rmbsum: newdate.rmbsum
							});
					});
					
				}else{
					layer.msg(http_data);
				}
				
			});

			
		  return false;
		});
    }
  });
  
//■■■■■■■■■■■ 搜索内容 ■■■■■■■■■■■■
  var $ = layui.$, active = {
    reload: function(){
      var demoReload = $('#demoReload');
      
      //执行重载
      table.reload('idTest', {
        page: {
          curr: 1 //重新从第 1 页开始
        },where: {
          searchkey: demoReload.val()
        }
      });
    }
  };
  
  $('.demoTable .layui-btn').on('click', function(){
    var type = $(this).data('type');
    active[type] ? active[type].call(this) : '';
  });
//■■■■■■■■■■■■ 排序排序排序 重新请求服务器 加载 ■■■■■■■■■■■■■■■
  table.on('sort(demo)', function(obj){ //注：tool是工具条事件名，test是table原始容器的属性 lay-filter="对应的值"
  table.reload('idTest', {  //table.reload 重新请求服务器
    initSort: obj //记录初始排序，如果不设的话，将无法标记表头的排序状态。 layui 2.1.1 新增参数
    ,where: { //请求参数（注意：这里面的参数可任意定义，并非下面固定的格式）
      field: obj.field //排序字段
      ,order: obj.type //排序方式
    }
  });
});
  
 //■■■■■■■■■■■■ 监听SVIP / VIP 操作 ■■■■■■■■■■■■
  form.on('switch(vlevel)', function(obj){
    layer.tips(this.name.split("|")[1] + '  -  '+ (obj.elem.checked == true ? '设置SVIP' : '设置VIP'), obj.othis);
	$.get("data/viplist.php", { vlevelupid:this.name.split("|")[0], vlevelupdate:obj.elem.checked == true ? 'svip' : 'vip'});
  });
//■■■■■■■■■■■■ 监听锁定操作 ■■■■■■■■■■■■■■■
  form.on('checkbox(ban)', function(obj){
    layer.tips(this.name.split("|")[1] + '  -  '+ (obj.elem.checked == true ? '封号' : '解除'), obj.othis);
	$.get("data/viplist.php", { banupid:this.name.split("|")[0], banupdate:obj.elem.checked == true ? 'disable' : 'enable'});
  });
//■■■■■■■■■■■■■ 添加VIP ■■■■■■■■■■■■■
	//监听添加内容按钮
  $('.demoTable .addVip').on('click', function(){

		 $("#taoid").val("");
		 $("#pass").val("");
		 $("#qq").val("");
		 $("#vx").val("");
		 $("#rmbsum").val("");
		
		//打开表单
		var newvip = layer.open({
		  type: 1,
		  title: '<b style="font-size:20px;color:#FF5722;margin-left: 140px;">新会员 <b>',
		  closeBtn: 1, 
		  shade: [0.3],
		  area: ['400px', '420px'],
		  offset: 'auto',  
		  content: $('#scEditor') 
		});
		
		//点击【提交】按钮
		form.on('submit(formDemo)', function(){
		  //提交表单
		  $.post("data/viplist.php",{
			  mode:'newVIP',
			  taoid: $("#taoid").val(),
			  pass: $("#pass").val(),
			  qq: $("#qq").val(),
			  vx: $("#vx").val(),
			  rmbsum: $("#rmbsum").val()
			}, function(data2){
				if(data2.search('成功')!=-1){
					
					//返回成功窗口
					layer.alert(data2, {
					 area: '200px'
					,skin: 'layui-layer-molv' //样式类名
					,closeBtn: 0
					});
					
					//清空表单，关闭窗口
					$("#taoid").val(""); 
					$("#pass").val(""); 
					$("#qq").val(""); 
					$("#vx").val(""); 
					$("#rmbsum").val(""); 
					layer.close(newvip);  
					
					//延迟1秒 执行重载
					setTimeout(function(){
						table.reload('idTest', {
							page: {
							  curr: 1 //重新从第 1 页开始
							},
							where: {
							  field: 'vid' //排序字段
							  ,order: 'desc' //排序方式
							}
						  });
					},1000);
					
				}else{
					layer.msg(data2);
				}

			});

			return false;
		})
		  
	});
//■■■■■■■■■■■■■ 批量添加素材 ■■■■■■■■■■■■■
	//监听编辑添加内容按钮
	$('.demoTable .addVips').on('click', function(){
		//打开表单
		var newvips = layer.open({
		  type: 1,
		  title: '<b style="font-size:20px;color:#FF5722;margin-left: 165px;">批量添加会员 <b>',
		  closeBtn: 1, 
		  shade: [0.3],
		  area: ['500px', '400px'],
		  offset: 'auto',  
		  content: $('#add_viplist_s') 
		});
		
		//点击【提交】按钮
		form.on('submit(getScData)', function(){
		  //提交表单
		  $.post("data/viplist.php",{
			  mode:'newVIPs',
			  newVipDatas: $("#addVipsData").val()
			}, function(data3){
				if(data3.search('成功')!=-1){
					//反馈成功 窗口
					layer.alert(data3, {
					  area: '700px'
					 ,skin: 'layui-layer-molv' //样式类名
					 ,closeBtn: 0
					});
					
					//清空表单 关闭窗口
					$("#addVipsData").val("");  
					layer.close(newvips);
					
					//延迟1秒 执行重载
					setTimeout(function(){
						table.reload('idTest', {
							page: {
							  curr: 1 //重新从第 1 页开始
							},
							where: {
							  field: 'vid' //排序字段
							  ,order: 'desc' //排序方式
							}
						  });
					},1000);
					
				}else{
					layer.msg(data3);
				}
			});
		
			return false;
		})
		  
	});

});
</script>
</body>
<!---编辑内容html模板 --->
<div style="display:none;margin:40px 50px 20px 10px" id="scEditor" > 
 <form class="layui-form" action="" method="post">
  <div class="layui-form-item">
    <label class="layui-form-label" style="fontsize:15px;">淘宝ID</label>
    <div class="layui-input-block">
      <input type="text" id="taoid" name="scid" required  lay-verify="required"  placeholder="" autocomplete="off" class="layui-input">
    </div>
  </div>
  <div class="layui-form-item">
    <label class="layui-form-label">取货密码</label>
    <div class="layui-input-block">
      <input type="text" id="pass" name="pass" required  lay-verify="required"  placeholder="" autocomplete="off" class="layui-input">
    </div>
  </div>
  <div class="layui-form-item">
    <label class="layui-form-label"><span style="color:#aaa;">(选填)</span> QQ</label>
    <div class="layui-input-block">
      <input type="text" id="qq" name="qq"    placeholder="" autocomplete="off" class="layui-input">
    </div>
  </div>
  <div class="layui-form-item">
    <label class="layui-form-label"><span style="color:#aaa;">(选填)</span> 微信</label>
    <div class="layui-input-block">
      <input type="text" id="vx" name="vx"    placeholder="" autocomplete="off" class="layui-input">
    </div>
  </div>
  <div class="layui-form-item">
    <label class="layui-form-label">付款金额</label>
    <div class="layui-input-block">
      <input type="text" id="rmbsum" name="rmbsum" required  lay-verify="required"  placeholder="" autocomplete="off" class="layui-input">
    </div>
  </div>
  <div class="layui-form-item">
    <div class="layui-input-block">
      <button class="layui-btn" lay-submit  lay-filter="formDemo">立即提交</button>
      <button type="reset" class="layui-btn layui-btn-primary">重置</button>
    </div>
  </div>
</form>
</div>
<div style="display:none;margin:30px 30px 0;" id="add_viplist_s" >
 <form class="layui-form" action="" method="post">
<textarea name="desc" id="addVipsData" style="height:240px;" placeholder="淘宝ID , 取货密码 , QQ(选填) , 微信(选填) , 金额  <回车换行> " class="layui-textarea"></textarea>
	<div style="margin:20px;text-align: center;">
		<button class="layui-btn" lay-submit  lay-filter="getScData">立即提交</button>
		<button type="reset" class="layui-btn layui-btn-primary">重置</button>
	</div>
 </form>
</div>
</html>       
        
EOF;

?>