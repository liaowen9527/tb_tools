<?php 
//数据库信息
$mysql_info = array(
	'host' => '127.0.0.1:3306', 
	'db'   => 'sucai', 
	'user' => 'root', 
	'pass' => 'weqeweqe', 
	);
	
// 连接服务器 + 检测连接
$conn = new mysqli($mysql_info["host"],$mysql_info["user"],$mysql_info["pass"],$mysql_info["db"]);
if ($conn->connect_error)     die("连接失败: " . $conn->connect_error);
$conn->query("set names 'utf8'");

//3600秒不活动  自动退出登陆
$out_login_time = 3600;

 //取货参数
$vip_day_num =10;   //VIP 每天10个
$vip_week_num =30;  //VIP 每周30个
$one_query_num=5;    //每次查询个数

//密码错误次数
$passerror_count=10;

?>