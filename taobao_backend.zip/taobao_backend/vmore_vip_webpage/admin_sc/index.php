﻿<?php
session_start();

if(@!empty($_SESSION["admin_hzh"] && @$_SESSION["ip_add"]==$_SERVER["REMOTE_ADDR"])){
echo <<<EOF
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport">
  <title>素材管理</title>
  <link rel="stylesheet" href="../layui/css/layui.css"  media="all">
  <link rel="stylesheet" href="../layui/css/a.css"  media="all">
  <link rel="stylesheet" href="../layui/css/ico/css/font-awesome.min.css">
</head>
<body class="layui-layout-body" style="width:1920px">
<div class="layui-layout layui-layout-admin">
  <div class="layui-header">
    <div class="layui-logo" style="font-size:18px; font-size: 20px;font-weight: 600;">自助取货管理系统</div>
    <!-- 头部区域（可配合layui已有的水平导航） -->
    <ul class="layui-nav layui-layout-right">
     <li class="layui-nav-item"><a id="logout" >退出登陆</a></li>
    </ul>
  </div>
  
  <div class="layui-side layui-bg-black">
    <div class="layui-side-scroll">
      <!-- 左侧导航区域（可配合layui已有的垂直导航） -->
      <ul class="layui-nav layui-nav-tree"  lay-filter="test">
        <li class="layui-nav-item layui-nav-itemed">
          <a class="hy" style="text-align: center;" href="javascript:;">会 员</a>
        </li>
		<li class="layui-nav-item layui-nav-itemed">
          <a class="sc" style="text-align: center;"  href="javascript:;">素 材</a>
        </li>
		<li class="layui-nav-item layui-nav-itemed">
		  <a class="log" style="text-align: center;"  href="javascript:;">记 录</a>
        </li>
 
      </ul>
    </div>
  </div>
  
  <div class="layui-body"style="bottom:0;width:1720px;">
    <!-- 内容主体区域 -->
    <div style="padding:0 0 0 15px;width:100%; height: 100%;overflow: hidden;" id='hy' class="" >
		<iframe src="index_vip.php" style="width: 100%; height: 100%; left: 0; top: 0;"frameborder="0" class="layadmin-iframe"></iframe>
	</div>
	<div style="padding:0 0 0 15px;width:100%; height: 100%;overflow: hidden;" id='sc' c class="none" >
		<iframe src="index_sc.php" style="width: 100%; height: 100%; left: 0; top: 0;"frameborder="0" class="layadmin-iframe"></iframe>
	</div>
	<div style="padding:0 0 0 15px;width:100%; height: 100%;overflow: hidden;" id='log' c class="none" >
		<iframe src="index_log.php" style="width: 100%; height: 100%; left: 0; top: 0;"frameborder="0" class="layadmin-iframe"></iframe>
	</div>
  </div>

</div>
<script src="../layui/layui.js" charset="utf-8"></script>
<script src="../layui/lay/modules/jquery.min.js" charset="utf-8"></script>
<script>
 layui.use('table', function(){
	var table = layui.table, 
	form = layui.form;
  
	 //退出登陆
	$("#logout").click(function(){
		layer.confirm('要退出登陆吗？', {icon: 3, title:'提示'}, function(index9){
	　　		$.get("function/login.php", {
					mode:'logout'
				},function(data){
					window.location.reload();
				})
		});
	});
  
});


$(".hy").click(function(){
  $("#hy").removeClass("none");
  $("#sc,#log").addClass("none");
});
$(".sc").click(function(){
  $("#sc").removeClass("none");
  $("#hy,#log").addClass("none");
});
$(".log").click(function(){
  $("#log").removeClass("none");
  $("#hy,#sc").addClass("none");
});
</script>
</body>
</html>
EOF;
}else{
	echo <<< EOF
<html><head>
  <meta charset="utf-8">
  <title>登入</title>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport">
  <link rel="stylesheet" href="../layui/css/layui.css" media="all">
  <link rel="stylesheet" href="../layui/css/admin.css" media="all">
  <link rel="stylesheet" href="../layui/css/login.css" media="all">
  <link rel="stylesheet" href="../layui/css/a.css" media="all">
  <link rel="stylesheet" href="../layui/css/ico/css/font-awesome.min.css">
  <script src="../layui/layui.js" charset="utf-8"></script>
  <script src="../layui/lay/modules/jquery.min.js" charset="utf-8"></script>
</head>
<body>
  <div class="layadmin-user-login layadmin-user-display-show" id="LAY-user-login" >
    <div class="layadmin-user-login-main">
      <div class="layadmin-user-login-box layadmin-user-login-header">
        <h2>登陆</h2>
      </div>
      <div class="layadmin-user-login-box layadmin-user-login-body layui-form">
	  <form action="" method="post">
        <div class="layui-form-item">
          <label class="fa fa-user-o" style="position:absolute;width: 38px;height: 38px;line-height:38px;text-align:center;font-size:1.3em;" for="LAY-user-login-username"></label>
          <input type="text" name="username" id="user" lay-verify="required" placeholder="用户名" class="layui-input">
        </div>
        <div class="layui-form-item">
          <label class="fa fa-lock" style="position:absolute;width: 38px;height: 38px;line-height:38px;text-align:center;font-size:1.5em;" for="LAY-user-login-password"></label>
          <input type="password" name="password"  id="pass"  lay-verify="required" placeholder="密码" class="layui-input">
		  <div class="pass"  style="display: none;">密码错误!</div>
        </div> 
		<div class="layui-form-item">
          <div class="layui-row">
            <div class="layui-col-xs7">
              <label class="fa fa-shield"  style="position:absolute;width: 38px;height: 38px;line-height:38px;text-align:center;font-size:1.5em;"  for="LAY-user-login-vercode"></label>
              <input type="text" name="vercode" id="vercode_txt" lay-verify="required" placeholder="图形验证码" class="layui-input">
            </div>
            <div class="layui-col-xs5">
              <div style="margin-left: 10px;">
                <img src="../function/yzm_img.php"  id="vercode_img" class="layadmin-user-login-codeimg"  >
              </div>
            </div>
          </div>
		  <div class="yzm no" style="display: none;">验证码错误！</div>
		  <div class="yzm yes" style="display: none;">验证通过！</div>
        </div>		
        <div class="layui-form-item">
          <button class="layui-btn layui-btn-fluid"  lay-submit   lay-filter="login">登 入</button>
        </div>
        </form>
      </div>
    </div>
  </div>
 <script>
 layui.use('table', function(){
	var table = layui.table, 
	form = layui.form;
 
	 $("#vercode_img").click(function(){
			var verifyimg = $('#vercode_img').attr('src');
			verifyimg = verifyimg.split("?")[0];
			$('#vercode_img').attr('src', verifyimg + '?random=' + Math.random());	
		})
		
		var  yzm_var='';
		$("#vercode_txt").bind('input propertychange',function(){
			if($('#vercode_txt').val().length>2){
				
				$.get("function/login.php", {
				  yzm_code: $('#vercode_txt').val()
				}, function(data6){
					if(data6=='1'){
						$(".yes").css("display","block");
						$(".no").css("display","none");
						yzm_var='1';
					}else{						
						$(".no").css("display","block");
						$(".yes").css("display","none");
						yzm_var='0';
					}
		 
				});
			}
		});
 
 
	 
	//表单
	form.on('submit(login)', function(){
		if(yzm_var==1){
			  //提交表单
			  $.post("function/login.php",{
				  username:$("#user").val(),
				  password:$("#pass").val(),
				  vercode:$("#vercode_txt").val()
				}, function(data5){
						//成功
						if(data5=='dlcg'){
							window.location.reload();
						//失败
						}else{
							//yzm重置
							yzm_var='0';
							
							var verifyimg = $('#vercode_img').attr('src');
							verifyimg = verifyimg.split("?")[0];
							$('#vercode_img').attr('src', verifyimg + '?random=' + Math.random());
							
							$(".no").css("display","none");
							$(".yes").css("display","none");
							
							$("#vercode_txt").val("");

							if(data5=='error'){
								$(".pass").css("display","block");
								$("#pass").val("");
							}

						}
		
				});

		}else{
			$(".no").css("display","block");
			$(".yes").css("display","none");
		} 
		return false;
	});
		//pass 
    $("#pass").blur(function(){
		$(".pass").css("display","none");
     }); 
 
 });
 </script>
</body></html>
	
EOF;
}
?>
