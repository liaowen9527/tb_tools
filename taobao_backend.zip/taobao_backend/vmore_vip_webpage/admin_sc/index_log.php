﻿<?php 
require_once('function/check.php'); 

echo <<<EOF
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>取货记录</title>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport">
  <link rel="stylesheet" href="../layui/css/layui.css"  media="all">
</head>
<body>
<form class="layui-form" action="" method="get">
<div class="demoTable" style="margin:15px">
    <div class="layui-inline">
      <label class="layui-form-label">日期范围</label>
      <div class="layui-input-inline">
        <input type="text" class="layui-input" style="width:200px;" id="data" placeholder="">
      </div>
    </div>
<span style="margin:0 5px;">关键词</span> 
  <div class="layui-inline">
    <input class="layui-input" name="id" id="demoReload" style="width:400px;" autocomplete="off">
  </div>
  <button class="layui-btn " lay-submit lay-filter="reloadUser" style="margin:0 0 0 10px;">搜会员</button>
  <button class="layui-btn " lay-submit lay-filter="reloadSc" >搜素材</button>
</div>
</form>

<table class="layui-table" lay-data="{width: 1160, height:783, url:'data/loglist.php', page:true, id:'idTest',  limit:20}" lay-filter="demo">
  <thead>
    <tr>
	 <th lay-data="{field:'logid', width:80,sort: true}">记录</th>
      <th lay-data="{field:'taoid',templet: '#name', width:380}">淘宝ID</th>
      <th lay-data="{field:'scid', width:100}">素材编号</th>
      <th lay-data="{field:'title', width:350}">素材名</th>
	  <th lay-data="{field:'logtime', width:200,templet: '#datatime',sort: true}">取货时间</th>
    </tr>
  </thead>
</table>
<script type="text/html" id="datatime">
{{# var logtime_css = d.logtime.split(" ") }}
{{logtime_css[0]}}<span style="color:#aaa;margin:0 0 0 8px;">{{logtime_css[1]}}</span>
</script>
<script type="text/html" id="name">
<span style="color:#b7b420;margin:0 5px 0 0; ">[{{d.vid}}]</span> {{d.taoid}}
<span style="border: 1px solid #676767; padding: 2px 6px; line-height: 14px; border-radius: 6px; margin: 4px 10px 0 0; float: right; " title="该用户取货总次数">总:<b style="color:#ff076c;font-weight:600">{{d.vidcount_all}}</b></span><span style="border: 1px solid #676767; padding: 2px 6px; line-height: 14px; border-radius: 6px; margin: 4px 10px 0 0; float: right; " title="选定时间内的取货次数">选:<b style="color:#29a9c7;font-weight:600">{{d.vidcount}}</b></span>
</script>
<script src="../layui/layui.js" charset="utf-8"></script>
<script src="../layui/lay/modules/jquery.min.js" charset="utf-8"></script>
<script>
layui.use('laydate', function(){
  var laydate = layui.laydate;
      //日期范围
  laydate.render({
    elem: '#data'
    ,range: true
  });
  
})
layui.use('table', function(){
  var table = layui.table, 
  form = layui.form;
  
  
//■■■■■■■■■■■ 搜索内容 USER ■■■■■■■■■■■■
	form.on('submit(reloadUser)', function(){
 
      //执行重载
      table.reload('idTest', {
        page: {
          curr: 1 //重新从第 1 页开始
        },where: {
		  mode:'user',
          searchkey: $("#demoReload").val(),
		  date: $("#data").val()
        }
      });
		return false;
	})
//■■■■■■■■■■■ 搜索内容 SC ■■■■■■■■■■■■
	form.on('submit(reloadSc)', function(){
 
      //执行重载
      table.reload('idTest', {
        page: {
          curr: 1 //重新从第 1 页开始
        },where: {
		  mode:'sc',
          searchkey: $("#demoReload").val(),
		  date: $("#data").val()
        }
      });
		return false;
	})
  
  
 
//■■■■■■■■■■■■ 排序排序排序 重新请求服务器 加载 ■■■■■■■■■■■■■■■
  table.on('sort(demo)', function(obj){ //注：tool是工具条事件名，test是table原始容器的属性 lay-filter="对应的值"
  table.reload('idTest', {  //table.reload 重新请求服务器
    initSort: obj //记录初始排序，如果不设的话，将无法标记表头的排序状态。 layui 2.1.1 新增参数
    ,where: { //请求参数（注意：这里面的参数可任意定义，并非下面固定的格式）
      field: obj.field //排序字段
      ,order: obj.type //排序方式
    }
  });
});
  


});
</script>
</body>
<!---编辑内容html模板 --->
</html>
EOF;
    
?>